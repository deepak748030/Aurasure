import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_card.dart';
import 'package:sixam_mart_delivery/common/widgets/title_widget.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/controllers/trip_controller.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Rider-specific trip count card.
/// Shows today's rides + today's earning from TripController (earning/summary).
/// Matches the _OrderCountCardWidget pattern from OrderCountWidget.
class RiderTripCountWidget extends StatelessWidget {
  const RiderTripCountWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TripController>(builder: (tripCtrl) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(
          Dimensions.paddingSizeDefault, 0,
          Dimensions.paddingSizeDefault, Dimensions.paddingSizeLarge,
        ),
        child: Column(children: [

          TitleWidget(title: 'rides'.tr),
          const SizedBox(height: Dimensions.paddingSizeExtraSmall),

          IntrinsicHeight(
            child: Row(children: [

              _TripCountCard(
                title: 'todays_rides'.tr,
                value: tripCtrl.todayRides.toString(),
              ),
              const SizedBox(width: Dimensions.paddingSizeDefault),

              _TripCountCard(
                title: 'today_earning'.tr,
                value: tripCtrl.todayEarning > 0
                    ? tripCtrl.todayEarning.toStringAsFixed(0)
                    : '0',
                isAmount: true,
              ),
              const SizedBox(width: Dimensions.paddingSizeDefault),

              _TripCountCard(
                title: 'this_week'.tr,
                value: tripCtrl.weekEarning > 0
                    ? tripCtrl.weekEarning.toStringAsFixed(0)
                    : '0',
                isAmount: true,
              ),

            ]),
          ),

        ]),
      );
    });
  }
}

class _TripCountCard extends StatelessWidget {
  final String title;
  final String? value;
  final bool isAmount;
  const _TripCountCard({required this.title, this.value, this.isAmount = false});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: CustomCard(
        isBorder: false,
        padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.paddingSizeExtraLarge,
          vertical: Dimensions.paddingSizeLarge,
        ),
        child: Column(children: [

          value != null
              ? Text(
                  value!,
                  style: robotoBold.copyWith(
                    fontSize: Dimensions.fontSizeExtraLarge,
                    color: Theme.of(context).textTheme.bodyLarge?.color,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                )
              : Shimmer(
                  duration: const Duration(seconds: 2),
                  color: Theme.of(context).shadowColor,
                  child: Container(
                    height: 15, width: 15,
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(5),
                    ),
                  ),
                ),
          const SizedBox(height: Dimensions.paddingSizeExtraSmall),

          Text(
            title,
            style: robotoRegular.copyWith(
              color: Theme.of(context).hintColor,
              fontSize: Dimensions.fontSizeSmall,
            ),
            textAlign: TextAlign.center,
          ),

        ]),
      ),
    );
  }
}
