import 'package:get/get.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_snackbar_widget.dart';
import '../domain/services/add_vehicle_service_interface.dart';

class AddVehicleController extends GetxController implements GetxService {
  final AddVehicleServiceInterface addVehicleServiceInterface;
  AddVehicleController({required this.addVehicleServiceInterface});

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  List<dynamic> _documents = [];
  List<dynamic> get documents => _documents;

  Future<void> getDocuments() async {
    _isLoading = true;
    update();
    final response = await addVehicleServiceInterface.getDocuments();
    _isLoading = false;
    if (response.statusCode == 200 && response.body != null) {
      _documents = response.body is List ? response.body as List : [];
    }
    update();
  }

  Future<bool> uploadDocument({
    required String documentType,
    required String frontImagePath,
    String? backImagePath,
    String? documentNumber,
    String? issuedOn,
    String? expiresOn,
  }) async {
    _isLoading = true;
    update();
    final response = await addVehicleServiceInterface.uploadDocument(
      documentType: documentType,
      frontImagePath: frontImagePath,
      backImagePath: backImagePath,
      documentNumber: documentNumber,
      issuedOn: issuedOn,
      expiresOn: expiresOn,
    );
    _isLoading = false;
    if (response.statusCode == 200) {
      showCustomSnackBar('document_uploaded_successfully'.tr, isError: false);
      await getDocuments();
      update();
      return true;
    }
    showCustomSnackBar(response.statusText ?? 'something_went_wrong'.tr);
    update();
    return false;
  }
}
