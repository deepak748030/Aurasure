import 'package:get/get_connect/http/src/response/response.dart';

abstract class TripRepositoryInterface {
  Future<Response> getTripList(int offset, {int limit = 20});
  Future<Response> getEarningSummary();
}
