import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/trip_details_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/screens/ride_details_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/controllers/trip_controller.dart';
import 'package:sixam_mart_delivery/helper/price_converter_helper.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Rider trip history — active and completed tabs.
/// Completely self-contained inside ride_module.
class RiderHistoryScreen extends StatefulWidget {
  const RiderHistoryScreen({super.key});

  @override
  State<RiderHistoryScreen> createState() => _RiderHistoryScreenState();
}

class _RiderHistoryScreenState extends State<RiderHistoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.find<RideController>().ongoingTripList();
      Get.find<TripController>().getTripList(1);
    });
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Text('history'.tr,
            style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
        bottom: TabBar(
          controller: _tab,
          labelColor: Theme.of(context).primaryColor,
          unselectedLabelColor: Theme.of(context).disabledColor,
          indicatorColor: Theme.of(context).primaryColor,
          tabs: [
            Tab(text: 'active'.tr),
            Tab(text: 'completed'.tr),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          // ── Active rides ──────────────────────────────────────────
          GetBuilder<RideController>(builder: (ctrl) {
            return _RideList(
              rides: ctrl.ongoingRide ?? [],
              isLoading: ctrl.isLoading,
              emptyLabel: 'no_active_rides'.tr,
              emptyIcon: Icons.directions_car_outlined,
            );
          }),

          // ── Completed rides ───────────────────────────────────────
          GetBuilder<TripController>(builder: (tripCtrl) {
            return RefreshIndicator(
              onRefresh: () => tripCtrl.getTripList(1),
              child: _RideList(
                rides: tripCtrl.tripModel?.tripList ?? [],
                isLoading: tripCtrl.isLoading,
                emptyLabel: 'no_completed_rides'.tr,
                emptyIcon: Icons.check_circle_outline,
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ── Ride list ──────────────────────────────────────────────────────────────

class _RideList extends StatelessWidget {
  final List<RideDetails> rides;
  final bool isLoading;
  final String emptyLabel;
  final IconData emptyIcon;

  const _RideList({
    required this.rides,
    required this.isLoading,
    required this.emptyLabel,
    required this.emptyIcon,
  });

  @override
  Widget build(BuildContext context) {
    if (isLoading && rides.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (rides.isEmpty) {
      return Center(child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(emptyIcon, size: 60, color: Theme.of(context).disabledColor),
          const SizedBox(height: Dimensions.paddingSizeSmall),
          Text(emptyLabel,
              style: robotoRegular.copyWith(
                color: Theme.of(context).disabledColor,
                fontSize: Dimensions.fontSizeDefault,
              )),
        ],
      ));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
      itemCount: rides.length,
      itemBuilder: (_, i) => _RideTile(ride: rides[i]),
    );
  }
}

// ── Ride tile ──────────────────────────────────────────────────────────────

class _RideTile extends StatelessWidget {
  final RideDetails ride;
  const _RideTile({required this.ride});

  @override
  Widget build(BuildContext context) {
    final status = ride.currentStatus ?? '';
    final statusColor = _statusColor(status, context);

    return GestureDetector(
      onTap: () => Get.to(() => RideDetailsScreen(ride: ride)),
      child: Container(
        margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          boxShadow: [BoxShadow(
            color: Theme.of(context).disabledColor.withValues(alpha: 0.15),
            blurRadius: 8, offset: const Offset(0, 2),
          )],
        ),
        child: Row(children: [

          // Icon
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
            ),
            child: Icon(Icons.directions_car,
                size: 22, color: Theme.of(context).primaryColor),
          ),
          const SizedBox(width: Dimensions.paddingSizeSmall),

          // Route info
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              ride.destinationAddress ?? 'Destination',
              style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault),
              maxLines: 1, overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 3),
            Text(
              ride.pickupAddress ?? 'Pickup',
              style: robotoRegular.copyWith(
                fontSize: Dimensions.fontSizeSmall,
                color: Theme.of(context).disabledColor,
              ),
              maxLines: 1, overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              ride.createdAt ?? '',
              style: robotoRegular.copyWith(
                fontSize: Dimensions.fontSizeSmall - 1,
                color: Theme.of(context).disabledColor,
              ),
            ),
          ])),

          // Fare + status
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(
              PriceConverterHelper.convertPrice(
                  double.tryParse(ride.totalFare ?? '0') ??
                      ride.paidFare ?? 0),
              style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                status.replaceAll('_', ' ').capitalizeFirst ?? status,
                style: TextStyle(
                  fontSize: Dimensions.fontSizeSmall - 1,
                  color: statusColor,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ]),

          const SizedBox(width: 4),
          Icon(Icons.chevron_right,
              size: 18, color: Theme.of(context).disabledColor),

        ]),
      ),
    );
  }

  Color _statusColor(String status, BuildContext context) {
    switch (status) {
      case 'completed':   return Theme.of(context).primaryColor;
      case 'cancelled':   return Colors.red;
      case 'in_progress': return Theme.of(context).colorScheme.error;
      case 'arriving':
      case 'arrived':     return Colors.orange;
      default:            return Theme.of(context).primaryColor;
    }
  }
}
