import 'package:get/get_connect/http/src/response/response.dart';
import '../repositories/leader_board_repository_interface.dart';
import 'leader_board_service_interface.dart';

class LeaderBoardService implements LeaderBoardServiceInterface {
  final LeaderBoardRepositoryInterface leaderBoardRepositoryInterface;
  LeaderBoardService({required this.leaderBoardRepositoryInterface});

  @override
  Future<Response> getLevel() =>
      leaderBoardRepositoryInterface.getLevel();
}
