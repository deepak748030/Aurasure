import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/trip_details_model.dart';
import 'package:sixam_mart_delivery/helper/price_converter_helper.dart';
import 'package:sixam_mart_delivery/helper/ride_helper.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

class RiderActiveRideCard extends StatelessWidget {
  const RiderActiveRideCard({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RideController>(builder: (ctrl) {
      // Use ongoingRide (active list) — lastRideDetails is the last *completed* ride.
      final RideDetails? ride = ctrl.ongoingRide?.isNotEmpty == true
          ? ctrl.ongoingRide!.first
          : null;

      final bool hasActive = ride != null &&
          ride.currentStatus != 'completed' &&
          ride.currentStatus != 'cancelled';

      if (!hasActive) return const SizedBox.shrink();

      return GestureDetector(
        onTap: () => RideHelper.navigateToNextScreen(id: ride!.id),
        child: Container(
          margin: const EdgeInsets.fromLTRB(
            Dimensions.paddingSizeDefault, 0,
            Dimensions.paddingSizeDefault, Dimensions.paddingSizeDefault,
          ),
          padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
            boxShadow: [BoxShadow(
              color: Theme.of(context).disabledColor.withValues(alpha: 0.3),
              blurRadius: 10,
            )],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('active_ride'.tr, style: robotoBold),
              TextButton(
                onPressed: () => RideHelper.navigateToNextScreen(id: ride!.id),
                child: Text('see_details'.tr,
                    style: robotoBold.copyWith(color: Theme.of(context).primaryColor)),
              ),
            ]),

            Text(
              '${'ride_id'.tr} # ${ride!.refId ?? ride.id}',
              style: robotoMedium.copyWith(color: Theme.of(context).disabledColor),
            ),
            const SizedBox(height: Dimensions.paddingSizeSmall),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
              decoration: BoxDecoration(
                color: Theme.of(context).disabledColor.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
              ),
              child: Column(children: [
                Text('est_trip_amount'.tr,
                    style: robotoBold.copyWith(color: Theme.of(context).disabledColor)),
                Text(
                  PriceConverterHelper.convertPrice(
                      double.tryParse(ride.estimatedFare ?? '0') ?? 0),
                  style: robotoBold.copyWith(fontSize: Dimensions.fontSizeExtraLarge),
                ),
                Text(
                  (ride.currentStatus ?? '').replaceAll('_', ' ').capitalizeFirst ?? '',
                  style: robotoRegular.copyWith(color: Theme.of(context).primaryColor),
                ),
              ]),
            ),
            const SizedBox(height: Dimensions.paddingSizeSmall),

            if (ride.estimatedTime != null)
              Center(
                child: Text(
                  '${'est_drop_off_time'.tr} - ${ride.estimatedTime} min',
                  style: robotoBold.copyWith(color: Theme.of(context).disabledColor),
                ),
              ),
            const SizedBox(height: Dimensions.paddingSizeSmall),

          ]),
        ),
      );
    });
  }
}
