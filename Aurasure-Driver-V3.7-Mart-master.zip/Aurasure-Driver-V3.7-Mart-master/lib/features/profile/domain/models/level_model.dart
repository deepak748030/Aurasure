/// Driver level / leaderboard model.
///
/// Shape inferred from the RideShare module consumers
/// (leaderboard_screen.dart, leader_board_controller.dart,
/// profile_level_details_widget.dart). Backed by the
/// `/api/v1/ride-share/driver/level` endpoint.
class LevelModel {
  Data? data;

  LevelModel({this.data});

  LevelModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (data != null) {
      map['data'] = data!.toJson();
    }
    return map;
  }
}

class Data {
  CurrentLevel? currentLevel;
  NextLevel? nextLevel;
  CompletedCurrentLevelTarget? completedCurrentLevelTarget;

  Data({this.currentLevel, this.nextLevel, this.completedCurrentLevelTarget});

  Data.fromJson(Map<String, dynamic> json) {
    currentLevel = json['current_level'] != null
        ? CurrentLevel.fromJson(json['current_level'])
        : null;
    nextLevel = json['next_level'] != null
        ? NextLevel.fromJson(json['next_level'])
        : null;
    completedCurrentLevelTarget = json['completed_current_level_target'] != null
        ? CompletedCurrentLevelTarget.fromJson(json['completed_current_level_target'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (currentLevel != null) map['current_level'] = currentLevel!.toJson();
    if (nextLevel != null) map['next_level'] = nextLevel!.toJson();
    if (completedCurrentLevelTarget != null) {
      map['completed_current_level_target'] = completedCurrentLevelTarget!.toJson();
    }
    return map;
  }
}

class CurrentLevel {
  int? id;
  String? name;
  double? targetedRide;
  double? targetedAmount;
  double? targetedReview;

  CurrentLevel({
    this.id,
    this.name,
    this.targetedRide,
    this.targetedAmount,
    this.targetedReview,
  });

  CurrentLevel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    targetedRide = _toDouble(json['targeted_ride']);
    targetedAmount = _toDouble(json['targeted_amount']);
    targetedReview = _toDouble(json['targeted_review']);
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'targeted_ride': targetedRide,
        'targeted_amount': targetedAmount,
        'targeted_review': targetedReview,
      };
}

class NextLevel {
  int? id;
  String? name;

  NextLevel({this.id, this.name});

  NextLevel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() => {'id': id, 'name': name};
}

class CompletedCurrentLevelTarget {
  double? rideComplete;
  double? earningAmount;
  double? reviewGiven;

  CompletedCurrentLevelTarget({
    this.rideComplete,
    this.earningAmount,
    this.reviewGiven,
  });

  CompletedCurrentLevelTarget.fromJson(Map<String, dynamic> json) {
    rideComplete = _toDouble(json['ride_complete']);
    earningAmount = _toDouble(json['earning_amount']);
    reviewGiven = _toDouble(json['review_given']);
  }

  Map<String, dynamic> toJson() => {
        'ride_complete': rideComplete,
        'earning_amount': earningAmount,
        'review_given': reviewGiven,
      };
}

double? _toDouble(dynamic value) {
  if (value == null) return null;
  if (value is num) return value.toDouble();
  return double.tryParse(value.toString());
}
