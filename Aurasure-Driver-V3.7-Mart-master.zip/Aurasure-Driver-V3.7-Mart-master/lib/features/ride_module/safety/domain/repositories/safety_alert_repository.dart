import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sixam_mart_delivery/api/api_client.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_constants.dart';
import 'safety_alert_repository_interface.dart';

class SafetyAlertRepository implements SafetyAlertRepositoryInterface {
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;
  SafetyAlertRepository({required this.apiClient, required this.sharedPreferences});

  // SOS uses the user-facing endpoint — driver triggers it on behalf of the ride
  static const String _sosUri = '/api/v1/ride-share/user/sos';

  Map<String, String> get _headers => {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization':
            'Bearer ${sharedPreferences.getString(RideConstants.tokenKey) ?? ''}',
      };

  @override
  Future<Response> triggerSos({required String rideId, required String message}) =>
      apiClient.postData(
        _sosUri,
        {'ride_id': rideId, 'message': message},
        headers: _headers,
      );
}
