import 'package:get/get_connect/http/src/response/response.dart';

abstract class RideOrderRepositoryInterface {
  // ── Auth ──────────────────────────────────────────────────────────────
  Future<Response> login(String phone, String password);
  Future<Response> logout();
  Future<Response> updateFcmToken(String token);
  Future<Response> getProfile();

  // ── Status ────────────────────────────────────────────────────────────
  Future<Response> toggleOnlineStatus(bool online);
  Future<Response> sendHeartbeat();

  // ── Location ──────────────────────────────────────────────────────────
  Future<Response> updateLocation({
    required double latitude,
    required double longitude,
    double? heading,
    double? speedKmph,
  });

  // ── Ride offers ───────────────────────────────────────────────────────
  Future<Response> getRideOffers();
  Future<Response> acceptRide(int rideId);
  Future<Response> rejectRide(int rideId);

  // ── Ride status updates ───────────────────────────────────────────────
  Future<Response> updateRideStatus(int rideId, String newStatus); // arriving | arrived
  Future<Response> startRide(int rideId, String otp);
  Future<Response> completeRide({
    required int rideId,
    required double actualDistanceKm,
    required double actualDurationMin,
    double waitingMinutes = 0,
    double tollAmount = 0,
  });

  // ── Ride list ─────────────────────────────────────────────────────────
  Future<Response> getRideList(String type, {int limit = 20, int offset = 1}); // active | completed

  // ── Earnings ──────────────────────────────────────────────────────────
  Future<Response> getEarningSummary();
  Future<Response> getEarningTransactions({int limit = 25, int offset = 1});

  // ── Documents ─────────────────────────────────────────────────────────
  Future<Response> getDocuments();

  // ── Token management ──────────────────────────────────────────────────
  String? getDriverToken();
  Future<void> saveDriverToken(String token);
  Future<void> clearDriverToken();
  bool isDriverLoggedIn();
}
