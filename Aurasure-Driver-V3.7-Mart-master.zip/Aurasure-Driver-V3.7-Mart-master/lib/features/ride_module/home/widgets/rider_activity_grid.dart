import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/common/widgets/title_widget.dart';
import 'package:sixam_mart_delivery/features/profile/controllers/profile_controller.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Today's time-tracking grid: online / driving / idle / offline.
/// Same data source as RideActivityView but self-contained in ride_module.
class RiderActivityGrid extends StatelessWidget {
  const RiderActivityGrid({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProfileController>(builder: (ctrl) {
      int online = 0, driving = 0, idle = 0, offline = 0;
      if (ctrl.profileModel?.timeTrack != null) {
        online  = ctrl.profileModel!.timeTrack!.totalOnline?.floor()  ?? 0;
        driving = ctrl.profileModel!.timeTrack!.totalDriving?.floor() ?? 0;
        idle    = ctrl.profileModel!.timeTrack!.totalIdle?.floor()    ?? 0;
        offline = ctrl.profileModel!.timeTrack!.totalOffline?.floor() ?? 0;
      }

      final items = [
        _ActivityItem('active'.tr,   online,  Colors.green),
        _ActivityItem('on_riding'.tr, driving, Colors.indigo),
        _ActivityItem('idle_time'.tr, idle,    Colors.orange),
        _ActivityItem('offline'.tr,  offline, Colors.red),
      ];

      return Container(
        margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          border: Border.all(
              color: Theme.of(context).disabledColor, width: 0.2),
          boxShadow: [BoxShadow(
            color: Get.isDarkMode
                ? Colors.white.withValues(alpha: 0.05)
                : Colors.black.withValues(alpha: 0.05),
            blurRadius: 20, spreadRadius: 0, offset: const Offset(0, 5),
          )],
        ),
        child: Column(children: [
          TitleWidget(title: 'ride_activity'.tr),
          const SizedBox(height: Dimensions.paddingSizeSmall),
          GridView.builder(
            itemCount: items.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: Dimensions.paddingSizeSmall,
              mainAxisSpacing: Dimensions.paddingSizeSmall,
              mainAxisExtent: 70,
            ),
            itemBuilder: (_, i) => Container(
              decoration: BoxDecoration(
                color: Theme.of(context).disabledColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
              ),
              padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(items[i].title,
                      style: robotoMedium.copyWith(
                        fontSize: Dimensions.fontSizeSmall,
                        color: Theme.of(context).textTheme.bodyLarge!.color!
                            .withValues(alpha: 0.5),
                      )),
                  const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                  Text(_fmt(items[i].seconds),
                      style: robotoBold.copyWith(
                        fontSize: Dimensions.fontSizeLarge,
                        color: items[i].color,
                      )),
                ],
              ),
            ),
          ),
        ]),
      );
    });
  }

  String _fmt(int seconds) {
    if (seconds < 60) return '$seconds ${'sec'.tr}';
    final mins = seconds ~/ 60;
    if (mins < 60) return '$mins ${'min'.tr}';
    final hrs = mins / 60;
    return '${hrs.toStringAsFixed(hrs % 1 == 0 ? 0 : 1)} ${'hour'.tr}';
  }
}

class _ActivityItem {
  final String title;
  final int seconds;
  final Color color;
  const _ActivityItem(this.title, this.seconds, this.color);
}
