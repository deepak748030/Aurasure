/// Compile-time app mode for the driver app.
///
/// Used by [AppConstants.appMode] and the RideShare module's `DriverMode`
/// helper to decide which feature set the build targets by default.
enum AppMode { delivery, ride }
