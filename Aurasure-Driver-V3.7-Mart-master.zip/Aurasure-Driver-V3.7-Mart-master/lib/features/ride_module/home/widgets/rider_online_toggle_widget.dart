import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Online/offline toggle card for ride drivers.
/// Delivery men use the profile active status — riders have their own toggle.
class RiderOnlineToggleWidget extends StatelessWidget {
  const RiderOnlineToggleWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RideController>(builder: (rideCtrl) {
      final bool isOnline = rideCtrl.isOnline;

      return Container(
        margin: const EdgeInsets.fromLTRB(
          Dimensions.paddingSizeDefault, 0,
          Dimensions.paddingSizeDefault, Dimensions.paddingSizeDefault,
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.paddingSizeLarge,
          vertical: Dimensions.paddingSizeDefault,
        ),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          border: Border.all(
            color: isOnline
                ? Theme.of(context).primaryColor.withValues(alpha: 0.3)
                : Theme.of(context).disabledColor.withValues(alpha: 0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Theme.of(context).disabledColor.withValues(alpha: 0.15),
              blurRadius: 10,
            ),
          ],
        ),
        child: Row(children: [

          // Status dot
          Container(
            width: 10, height: 10,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isOnline ? Colors.green : Theme.of(context).disabledColor,
            ),
          ),
          const SizedBox(width: Dimensions.paddingSizeSmall),

          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                isOnline ? 'you_are_online'.tr : 'you_are_offline'.tr,
                style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault),
              ),
              Text(
                isOnline
                    ? 'you_can_receive_ride_requests'.tr
                    : 'go_online_to_receive_ride_requests'.tr,
                style: robotoRegular.copyWith(
                  fontSize: Dimensions.fontSizeSmall,
                  color: Theme.of(context).textTheme.bodyLarge!.color!.withValues(alpha: 0.6),
                ),
              ),
            ]),
          ),

          // Toggle switch
          Transform.scale(
            scale: 0.85,
            child: Switch(
              value: isOnline,
              activeColor: Theme.of(context).primaryColor,
              onChanged: rideCtrl.isLoading
                  ? null
                  : (val) => rideCtrl.toggleOnline(val),
            ),
          ),

        ]),
      );
    });
  }
}
