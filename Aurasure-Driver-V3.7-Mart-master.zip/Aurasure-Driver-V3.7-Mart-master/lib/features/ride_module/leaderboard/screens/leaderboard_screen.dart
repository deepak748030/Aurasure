import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/profile/domain/models/level_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/leaderboard/controllers/leader_board_controller.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Driver leaderboard / level screen.
/// Shows current level, next level targets, and progress.
class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.find<LeaderBoardController>().getLevel();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        elevation: 0,
        title: Text('leader_board'.tr,
            style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: GetBuilder<LeaderBoardController>(builder: (ctrl) {
        if (ctrl.isLoading && ctrl.levelModel == null) {
          return const Center(child: CircularProgressIndicator());
        }

        // No levels configured on the backend
        if (ctrl.levelModel?.data == null) {
          return Center(child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.emoji_events_outlined, size: 64,
                  color: Theme.of(context).disabledColor),
              const SizedBox(height: Dimensions.paddingSizeSmall),
              Text('no_levels_available'.tr,
                  style: robotoMedium.copyWith(
                    color: Theme.of(context).disabledColor,
                    fontSize: Dimensions.fontSizeDefault,
                  )),
              const SizedBox(height: Dimensions.paddingSizeExtraSmall),
              Text('admin_has_not_configured_levels_yet'.tr,
                  style: robotoRegular.copyWith(
                    color: Theme.of(context).disabledColor,
                    fontSize: Dimensions.fontSizeSmall,
                  )),
            ],
          ));
        }

        final Data? data = ctrl.levelModel?.data;
        final current = data?.currentLevel;
        final next    = data?.nextLevel;
        final done    = data?.completedCurrentLevelTarget;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
          child: Column(children: [

            // ── Current level card ────────────────────────────────────
            if (current != null)
              _LevelCard(
                title: 'current_level'.tr,
                name: current.name ?? '-',
                color: Colors.orange,
                icon: Icons.emoji_events_rounded,
              ),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            // ── Progress ──────────────────────────────────────────────
            if (done != null && current != null)
              _ProgressCard(current: current, done: done),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            // ── Next level ────────────────────────────────────────────
            if (next != null)
              _LevelCard(
                title: 'next_level'.tr,
                name: next.name ?? '-',
                color: Theme.of(context).primaryColor,
                icon: Icons.arrow_upward_rounded,
              )
            else
              _MaxLevelBadge(),

          ]),
        );
      }),
    );
  }
}

class _LevelCard extends StatelessWidget {
  final String title;
  final String name;
  final Color color;
  final IconData icon;
  const _LevelCard({required this.title, required this.name, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        boxShadow: [BoxShadow(
          color: Theme.of(context).disabledColor.withValues(alpha: 0.12),
          blurRadius: 10,
        )],
      ),
      child: Row(children: [
        Container(
          width: 48, height: 48,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(width: Dimensions.paddingSizeDefault),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: robotoRegular.copyWith(
                fontSize: Dimensions.fontSizeSmall,
                color: Theme.of(context).disabledColor,
              )),
          Text(name,
              style: robotoBold.copyWith(
                fontSize: Dimensions.fontSizeLarge,
                color: color,
              )),
        ]),
      ]),
    );
  }
}

class _ProgressCard extends StatelessWidget {
  final CurrentLevel current;
  final CompletedCurrentLevelTarget done;
  const _ProgressCard({required this.current, required this.done});

  @override
  Widget build(BuildContext context) {
    final items = <_ProgressItem>[
      _ProgressItem('rides_completed'.tr, done.rideComplete ?? 0, current.targetedRide ?? 0),
      _ProgressItem('earning_amount'.tr,  done.earningAmount ?? 0, current.targetedAmount ?? 0),
      _ProgressItem('reviews_given'.tr,   done.reviewGiven ?? 0, current.targetedReview ?? 0),
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        boxShadow: [BoxShadow(
          color: Theme.of(context).disabledColor.withValues(alpha: 0.12),
          blurRadius: 10,
        )],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('progress'.tr, style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault)),
        const SizedBox(height: Dimensions.paddingSizeDefault),
        ...items.map((item) => _ProgressRow(item: item)),
      ]),
    );
  }
}

class _ProgressItem {
  final String label;
  final double done;
  final double target;
  const _ProgressItem(this.label, this.done, this.target);
}

class _ProgressRow extends StatelessWidget {
  final _ProgressItem item;
  const _ProgressRow({required this.item});

  @override
  Widget build(BuildContext context) {
    final pct = item.target > 0 ? (item.done / item.target).clamp(0.0, 1.0) : 0.0;
    return Padding(
      padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeDefault),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(item.label,
              style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall)),
          Text('${item.done.toStringAsFixed(0)} / ${item.target.toStringAsFixed(0)}',
              style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall)),
        ]),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: pct,
            minHeight: 8,
            backgroundColor: Theme.of(context).disabledColor.withValues(alpha: 0.15),
            valueColor: AlwaysStoppedAnimation(Theme.of(context).primaryColor),
          ),
        ),
      ]),
    );
  }
}

class _MaxLevelBadge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
      decoration: BoxDecoration(
        color: Colors.amber.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        border: Border.all(color: Colors.amber.withValues(alpha: 0.4)),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.workspace_premium_rounded, color: Colors.amber, size: 28),
        const SizedBox(width: Dimensions.paddingSizeSmall),
        Text('you_are_at_the_highest_level'.tr,
            style: robotoBold.copyWith(color: Colors.amber)),
      ]),
    );
  }
}
