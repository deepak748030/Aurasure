import 'dart:io';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sixam_mart_delivery/api/api_client.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_constants.dart';
import 'add_vehicle_repository_interface.dart';

class AddVehicleRepository implements AddVehicleRepositoryInterface {
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;
  AddVehicleRepository({required this.sharedPreferences, required this.apiClient});

  Map<String, String> get _headers => {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization':
            'Bearer ${sharedPreferences.getString(RideConstants.tokenKey) ?? ''}',
      };

  @override
  Future<Response> getDocuments() =>
      apiClient.getData(RideConstants.documentsUri, headers: _headers);

  @override
  Future<Response> uploadDocument({
    required String documentType,
    required String frontImagePath,
    String? backImagePath,
    String? documentNumber,
    String? issuedOn,
    String? expiresOn,
  }) async {
    final fields = <String, String>{
      'document_type': documentType,
      if (documentNumber != null) 'document_number': documentNumber,
      if (issuedOn != null) 'issued_on': issuedOn,
      if (expiresOn != null) 'expires_on': expiresOn,
    };
    final parts = [
      MultipartBody('front_image', await _toXFile(frontImagePath)),
      if (backImagePath != null)
        MultipartBody('back_image', await _toXFile(backImagePath)),
    ];
    return apiClient.postMultipartData(
      RideConstants.documentsUri,
      fields,
      parts,
      headers: _headers,
    );
  }

  Future<dynamic> _toXFile(String path) async {
    // Returns an XFile-compatible object for postMultipartData
    return _XFileLike(path);
  }
}

/// Minimal XFile-compatible wrapper so we can pass a path to postMultipartData.
class _XFileLike {
  final String path;
  const _XFileLike(this.path);
  Future<int> length() async => File(path).lengthSync();
  Future<List<int>> readAsBytes() async => File(path).readAsBytesSync();
}
