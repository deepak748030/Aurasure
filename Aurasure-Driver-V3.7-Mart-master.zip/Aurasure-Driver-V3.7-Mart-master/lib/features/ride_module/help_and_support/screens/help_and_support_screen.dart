import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/helper/route_helper.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Help & support screen for ride drivers.
class HelpAndSupportScreen extends StatelessWidget {
  const HelpAndSupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      _HelpItem(
        icon: Icons.chat_bubble_outline_rounded,
        title: 'conversation'.tr,
        subtitle: 'chat_with_support'.tr,
        onTap: () => Get.toNamed(RouteHelper.getConversationListRoute()),
      ),
      _HelpItem(
        icon: Icons.description_outlined,
        title: 'terms_condition'.tr,
        subtitle: 'read_our_terms'.tr,
        onTap: () => Get.toNamed(RouteHelper.getTermsRoute()),
      ),
      _HelpItem(
        icon: Icons.privacy_tip_outlined,
        title: 'privacy_policy'.tr,
        subtitle: 'read_our_privacy_policy'.tr,
        onTap: () => Get.toNamed(RouteHelper.getPrivacyRoute()),
      ),
    ];

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        elevation: 0,
        title: Text('help_and_support'.tr,
            style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: Dimensions.paddingSizeSmall),
        itemBuilder: (_, i) {
          final item = items[i];
          return InkWell(
            onTap: item.onTap,
            borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
            child: Container(
              padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                boxShadow: [BoxShadow(
                  color: Theme.of(context).disabledColor.withValues(alpha: 0.1),
                  blurRadius: 8, offset: const Offset(0, 2),
                )],
              ),
              child: Row(children: [
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
                  ),
                  child: Icon(item.icon, color: Theme.of(context).primaryColor, size: 22),
                ),
                const SizedBox(width: Dimensions.paddingSizeDefault),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(item.title, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeDefault)),
                  Text(item.subtitle,
                      style: robotoRegular.copyWith(
                        fontSize: Dimensions.fontSizeSmall,
                        color: Theme.of(context).disabledColor,
                      )),
                ])),
                Icon(Icons.chevron_right, color: Theme.of(context).disabledColor),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class _HelpItem {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _HelpItem({required this.icon, required this.title, required this.subtitle, required this.onTap});
}
