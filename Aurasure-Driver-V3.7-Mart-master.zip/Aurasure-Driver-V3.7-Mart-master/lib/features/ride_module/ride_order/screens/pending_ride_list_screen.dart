import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/trip_details_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/screens/ride_order_screen.dart';

/// Shows incoming ride offer cards.
/// Driver can accept or reject each offer.
class PendingRideListScreen extends StatefulWidget {
  const PendingRideListScreen({super.key});

  @override
  State<PendingRideListScreen> createState() => _PendingRideListScreenState();
}

class _PendingRideListScreenState extends State<PendingRideListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctrl = Get.find<RideController>();
      // Start polling only if already online
      if (ctrl.isOnline) {
        ctrl.getPendingRideRequestList(1, isUpdate: true);
        ctrl.startOfferPolling();
      }
    });
  }

  @override
  void dispose() {
    Get.find<RideController>().stopOfferPolling();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('Ride Offers',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: Theme.of(context).cardColor,
        foregroundColor: Theme.of(context).textTheme.bodyLarge?.color,
        elevation: 0,
        actions: [
          // ── Online / Offline toggle ──────────────────────────
          GetBuilder<RideController>(builder: (ctrl) {
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    ctrl.isOnline ? 'Online' : 'Offline',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).textTheme.bodyLarge?.color,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Switch(
                    value: ctrl.isOnline,
                    onChanged: (v) => ctrl.toggleOnline(v),
                    activeColor: Theme.of(context).primaryColor,
                  ),
                ],
              ),
            );
          }),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => Get.find<RideController>()
                .getPendingRideRequestList(1, isUpdate: true),
          ),
        ],
      ),
      body: GetBuilder<RideController>(builder: (ctrl) {
        // ── Offline state ──────────────────────────────────────
        if (!ctrl.isOnline) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: Theme.of(context).disabledColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(40),
                  ),
                  child: Icon(Icons.power_settings_new,
                      size: 40, color: Theme.of(context).disabledColor),
                ),
                const SizedBox(height: 20),
                Text('You are offline',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).textTheme.bodyLarge?.color)),
                const SizedBox(height: 8),
                Text('Toggle the switch above to go online\nand start receiving ride offers',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 14, color: Theme.of(context).disabledColor)),
                const SizedBox(height: 32),
                ElevatedButton.icon(
                  onPressed: ctrl.isLoading
                      ? null
                      : () => ctrl.toggleOnline(true),
                  icon: ctrl.isLoading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.power_settings_new),
                  label: const Text('Go Online'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 32, vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          );
        }

        // ── Online — show offers ───────────────────────────────
        final offers = ctrl.pendingRideRequestModel?.data ?? [];

        if (ctrl.isLoading && offers.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        if (offers.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.directions_car_outlined,
                    size: 64, color: Theme.of(context).disabledColor),
                const SizedBox(height: 16),
                Text('No ride offers right now',
                    style: TextStyle(
                        fontSize: 16, color: Theme.of(context).textTheme.bodyLarge?.color)),
                const SizedBox(height: 8),
                Text('Waiting for new ride requests...',
                    style: TextStyle(
                        fontSize: 13, color: Theme.of(context).disabledColor)),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () => ctrl.getPendingRideRequestList(1,
                      isUpdate: true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text('Refresh'),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: offers.length,
          itemBuilder: (_, i) => _OfferCard(
            ride: offers[i],
            onAccept: () async {
              final id = int.tryParse(offers[i].id ?? '');
              if (id == null) return;
              final ok = await ctrl.acceptOffer(id);
              if (ok) {
                Get.off(() => const RideOrderScreen());
              }
            },
            onReject: () {
              final id = int.tryParse(offers[i].id ?? '');
              if (id != null) ctrl.rejectOffer(id);
            },
          ),
        );
      }),
    );
  }
}

// ── Offer card ─────────────────────────────────────────────────────────────
class _OfferCard extends StatelessWidget {
  final RideDetails ride;
  final VoidCallback onAccept;
  final VoidCallback onReject;

  const _OfferCard({
    required this.ride,
    required this.onAccept,
    required this.onReject,
  });

  @override
  Widget build(BuildContext context) {
    final fare = ride.totalFare ?? ride.estimatedFare ?? '0';
    final pickup = ride.pickupAddress ?? 'Pickup';
    final dest = ride.destinationAddress ?? 'Destination';
    final dist = ride.estimatedDistance?.toStringAsFixed(1) ?? '?';
    final time = ride.estimatedTime ?? '?';

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          // ── Header ─────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Row(
              children: [
                const Icon(Icons.directions_car,
                    color: Colors.white, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    ride.vehicleCategory?.name ?? 'Standard',
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 15),
                  ),
                ),
                Text(
                  '₹$fare',
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18),
                ),
              ],
            ),
          ),

          // ── Route ──────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    Container(
                      width: 10, height: 10,
                      decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor, shape: BoxShape.circle),
                    ),
                    Container(width: 1.5, height: 28,
                        color: Theme.of(context).dividerTheme.color ?? Colors.grey.shade300),
                    Container(
                      width: 10, height: 10,
                      decoration: BoxDecoration(
                        border: Border.all(
                            color: Theme.of(context).primaryColor, width: 2),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(pickup,
                          style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w500),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 16),
                      Text(dest,
                          style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w500),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Stats ──────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(
              children: [
                _Stat(icon: Icons.straighten, label: '$dist km'),
                const SizedBox(width: 16),
                _Stat(icon: Icons.access_time, label: '$time min'),
                const SizedBox(width: 16),
                _Stat(
                  icon: Icons.payment,
                  label: ride.paymentMethod ?? 'cash',
                ),
              ],
            ),
          ),

          // ── Actions ────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: onReject,
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      side: BorderSide(color: Theme.of(context).dividerTheme.color ?? Colors.grey.shade300),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    child: Text('Reject',
                        style: TextStyle(
                            color: Theme.of(context).textTheme.bodyMedium?.color,
                            fontWeight: FontWeight.w600)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: onAccept,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).primaryColor,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text('Accept Ride',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 15)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Stat({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: const Color(0xFF888888)),
        const SizedBox(width: 4),
        Text(label,
            style: const TextStyle(
                fontSize: 12, color: Color(0xFF888888))),
      ],
    );
  }
}

/// Legacy alias — dashboard_screen.dart uses `RideRequestScreen(onTap: ...)`.
/// This class wraps [PendingRideListScreen] and accepts the `onTap` param
/// (which is unused — the screen handles its own navigation).
class RideRequestScreen extends StatelessWidget {
  final VoidCallback? onTap;
  const RideRequestScreen({super.key, this.onTap});

  @override
  Widget build(BuildContext context) => const PendingRideListScreen();
}
