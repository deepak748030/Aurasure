import 'package:get/get_connect/http/src/response/response.dart';
import '../repositories/trip_repository_interface.dart';
import 'trip_service_interface.dart';

class TripService implements TripServiceInterface {
  final TripRepositoryInterface tripRepositoryInterface;
  TripService({required this.tripRepositoryInterface});

  @override
  Future<Response> getTripList(int offset, {int limit = 20}) =>
      tripRepositoryInterface.getTripList(offset, limit: limit);

  @override
  Future<Response> getEarningSummary() =>
      tripRepositoryInterface.getEarningSummary();
}
