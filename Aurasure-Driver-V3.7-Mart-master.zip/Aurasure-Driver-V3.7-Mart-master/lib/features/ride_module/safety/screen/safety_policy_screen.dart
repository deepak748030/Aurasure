import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_config_extension.dart';
import 'package:sixam_mart_delivery/features/splash/controllers/splash_controller.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Safety policy screen for ride drivers.
/// Shows safety feature status and emergency contact from config.
class SafetyPolicyScreen extends StatelessWidget {
  const SafetyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final config = Get.find<SplashController>().configModel;
    final rideConfig = Get.find<SplashController>().rideConfig;

    final bool safetyEnabled = (rideConfig?.safetyFeatureStatus ?? 0) == 1;
    final String? emergencyNumber = rideConfig?.safetyFeatureEmergencyGovtNumber;
    final int? delayTime = rideConfig?.safetyFeatureMinimumTripDelayTime;
    final String? delayType = rideConfig?.safetyFeatureMinimumTripDelayTimeType;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        elevation: 0,
        title: Text('safety'.tr,
            style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        child: Column(children: [

          // ── Safety status card ────────────────────────────────────
          _InfoCard(children: [
            _Row(
              icon: safetyEnabled ? Icons.shield_rounded : Icons.shield_outlined,
              iconColor: safetyEnabled ? Colors.green : Theme.of(context).disabledColor,
              label: 'safety_feature'.tr,
              value: safetyEnabled ? 'enabled'.tr : 'disabled'.tr,
            ),
            if (emergencyNumber != null && emergencyNumber.isNotEmpty)
              _Row(
                icon: Icons.phone_outlined,
                iconColor: Theme.of(context).primaryColor,
                label: 'emergency_number'.tr,
                value: emergencyNumber,
              ),
            if (delayTime != null)
              _Row(
                icon: Icons.timer_outlined,
                iconColor: Colors.orange,
                label: 'safety_check_delay'.tr,
                value: '$delayTime ${delayType ?? 'min'}',
              ),
          ]),
          const SizedBox(height: Dimensions.paddingSizeDefault),

          // ── Safety tips ───────────────────────────────────────────
          _InfoCard(children: [
            Padding(
              padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
              child: Text('safety_tips'.tr,
                  style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault)),
            ),
            _Tip(icon: Icons.lock_outline, text: 'always_verify_otp_before_starting_ride'.tr),
            _Tip(icon: Icons.route_outlined, text: 'follow_the_designated_route'.tr),
            _Tip(icon: Icons.report_problem_outlined, text: 'report_any_suspicious_activity'.tr),
            _Tip(icon: Icons.emergency_outlined, text: 'use_sos_button_in_emergency'.tr),
          ]),

        ]),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final List<Widget> children;
  const _InfoCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        boxShadow: [BoxShadow(
          color: Theme.of(context).disabledColor.withValues(alpha: 0.12),
          blurRadius: 10,
        )],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );
  }
}

class _Row extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String value;
  const _Row({required this.icon, required this.iconColor, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(children: [
        Icon(icon, size: 20, color: iconColor),
        const SizedBox(width: Dimensions.paddingSizeSmall),
        Expanded(child: Text(label,
            style: robotoRegular.copyWith(
              fontSize: Dimensions.fontSizeSmall,
              color: Theme.of(context).disabledColor,
            ))),
        Text(value, style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall)),
      ]),
    );
  }
}

class _Tip extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Tip({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, size: 18, color: Theme.of(context).primaryColor),
        const SizedBox(width: Dimensions.paddingSizeSmall),
        Expanded(child: Text(text,
            style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall))),
      ]),
    );
  }
}
