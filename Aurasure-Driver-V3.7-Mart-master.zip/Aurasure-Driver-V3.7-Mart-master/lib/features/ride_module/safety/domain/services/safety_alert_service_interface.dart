import 'package:get/get_connect/http/src/response/response.dart';

abstract class SafetyAlertServiceInterface {
  Future<Response> triggerSos({required String rideId, required String message});
}
