/// RideShare module constants used by core files (auth_repository.dart).
///
/// All driver API endpoints used inside ride_module/ live in RideConstants.
/// This file only contains the constants that core files need to reference
/// without importing ride_module code directly.
class RideAppConstants {
  // ── Driver auth endpoints (used by auth_repository.dart) ─────────────
  static const String driverLoginUri   = '/api/v1/ride-share/driver/auth/login';
  static const String riderRegisterUri = '/api/v1/ride-share/driver/auth/register';
  static const String driverFcmTokenUri= '/api/v1/ride-share/driver/fcm-token';

  // ── SharedPreferences keys ────────────────────────────────────────────
  static const String driverTokenKey = 'ride_share_driver_token';
  static const String isRideUserKey  = 'is_ride_user';

  // ── FCM topic ─────────────────────────────────────────────────────────
  static const String topicRider = 'all_zone_rider';

  // ── Role identifiers (mirrors AppConstants — kept for cross-module use) ─
  static const String isRide     = 'is_ride';
  static const String isDelivery = 'is_delivery';
}
