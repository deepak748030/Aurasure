import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

class RiderOnlineToggle extends StatelessWidget {
  const RiderOnlineToggle({super.key});

  Future<void> _toggleAndSendLocation(RideController ctrl, bool online) async {
    await ctrl.toggleOnline(online);
    if (online) {
      // Send real GPS coordinates immediately after going online
      try {
        final permission = await Permission.location.status;
        if (permission.isGranted) {
          final pos = await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
          );
          await ctrl.updateLocation(pos.latitude, pos.longitude, heading: pos.heading);
        }
      } catch (_) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RideController>(builder: (ctrl) {
      final bool online = ctrl.isOnline;
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
        padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.paddingSizeLarge,
          vertical: Dimensions.paddingSizeDefault,
        ),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          border: Border.all(
            color: online
                ? Colors.green.withValues(alpha: 0.4)
                : Theme.of(context).disabledColor.withValues(alpha: 0.3),
          ),
          boxShadow: [BoxShadow(
            color: Theme.of(context).disabledColor.withValues(alpha: 0.12),
            blurRadius: 10,
          )],
        ),
        child: Row(children: [
          Container(
            width: 10, height: 10,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: online ? Colors.green : Theme.of(context).disabledColor,
            ),
          ),
          const SizedBox(width: Dimensions.paddingSizeSmall),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              online ? 'you_are_online'.tr : 'you_are_offline'.tr,
              style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault),
            ),
            Text(
              online
                  ? 'you_can_receive_ride_requests'.tr
                  : 'go_online_to_receive_ride_requests'.tr,
              style: robotoRegular.copyWith(
                fontSize: Dimensions.fontSizeSmall,
                color: Theme.of(context).textTheme.bodyLarge!.color!.withValues(alpha: 0.55),
              ),
            ),
          ])),
          Transform.scale(
            scale: 0.85,
            child: Switch(
              value: online,
              activeColor: Theme.of(context).primaryColor,
              onChanged: ctrl.isLoading ? null : (v) => _toggleAndSendLocation(ctrl, v),
            ),
          ),
        ]),
      );
    });
  }
}
