import 'package:get/get_connect/http/src/response/response.dart';
import '../repositories/safety_alert_repository_interface.dart';
import 'safety_alert_service_interface.dart';

class SafetyAlertService implements SafetyAlertServiceInterface {
  final SafetyAlertRepositoryInterface safetyAlertRepositoryInterface;
  SafetyAlertService({required this.safetyAlertRepositoryInterface});

  @override
  Future<Response> triggerSos({required String rideId, required String message}) =>
      safetyAlertRepositoryInterface.triggerSos(rideId: rideId, message: message);
}
