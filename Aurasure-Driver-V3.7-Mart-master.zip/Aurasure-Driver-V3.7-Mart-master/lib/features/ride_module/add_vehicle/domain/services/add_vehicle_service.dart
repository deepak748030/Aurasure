import 'package:get/get_connect/http/src/response/response.dart';
import '../repositories/add_vehicle_repository_interface.dart';
import 'add_vehicle_service_interface.dart';

class AddVehicleService implements AddVehicleServiceInterface {
  final AddVehicleRepositoryInterface addVehicleRepositoryInterface;
  AddVehicleService({required this.addVehicleRepositoryInterface});

  @override
  Future<Response> getDocuments() =>
      addVehicleRepositoryInterface.getDocuments();

  @override
  Future<Response> uploadDocument({
    required String documentType,
    required String frontImagePath,
    String? backImagePath,
    String? documentNumber,
    String? issuedOn,
    String? expiresOn,
  }) =>
      addVehicleRepositoryInterface.uploadDocument(
        documentType: documentType,
        frontImagePath: frontImagePath,
        backImagePath: backImagePath,
        documentNumber: documentNumber,
        issuedOn: issuedOn,
        expiresOn: expiresOn,
      );
}
