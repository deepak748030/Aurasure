import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sixam_mart_delivery/api/api_client.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_constants.dart';
import 'review_repository_interface.dart';

class ReviewRepository implements ReviewRepositoryInterface {
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;
  ReviewRepository({required this.apiClient, required this.sharedPreferences});

  Map<String, String> get _headers => {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization':
            'Bearer ${sharedPreferences.getString(RideConstants.tokenKey) ?? ''}',
      };

  @override
  Future<Response> getDriverProfile() =>
      apiClient.getData(RideConstants.profileUri, headers: _headers);
}
