import 'package:get/get.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_loader.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_constants.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/screens/ride_order_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/screens/ride_details_screen.dart';

/// Navigates to the correct screen for a given ride ID.
///
/// Active statuses (accepted / arriving / arrived / in_progress) → RideOrderScreen
///   The controller's _rideId and _rideState are restored by getRideDetails()
///   before navigation so all action buttons work immediately.
///
/// Terminal / other statuses → RideDetailsScreen (read-only summary)
class RideHelper {
  static void navigateToNextScreen({
    String? id,
    bool fromRideListScreen = false,
  }) async {
    if (id == null || id.isEmpty) return;

    Get.dialog(const CustomLoaderWidget());

    final rideDetails =
        await Get.find<RideController>().getRideDetails(id);

    if (Get.isDialogOpen == true) Get.back();

    if (rideDetails == null) return;

    final status = rideDetails.currentStatus ?? '';

    // Active statuses — open the action screen.
    // Use a plain Set<String> (not const) to avoid duplicate-element errors
    // since RideConstants.ongoing == RideConstants.statusInProgress == 'in_progress'.
    final activeStatuses = <String>{
      RideConstants.statusAccepted,   // 'accepted'
      RideConstants.statusArriving,   // 'arriving'
      RideConstants.statusArrived,    // 'arrived'
      RideConstants.statusInProgress, // 'in_progress'
    };

    if (activeStatuses.contains(status)) {
      // getRideDetails() already restored _rideId and _rideState,
      // so RideOrderScreen's action buttons will work immediately.
      Get.to(() => const RideOrderScreen());
      return;
    }

    // All other statuses (completed, cancelled, no_driver_found, etc.)
    // → read-only details screen
    Get.to(() => RideDetailsScreen(
          rideId: id,
          rideDetails: rideDetails,
          fromListScreen: fromRideListScreen,
        ));
  }
}
