import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/common/widgets/confirmation_dialog_widget.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_button_widget.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_bottom_sheet_widget.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_confirmation_bottom_sheet.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_image_widget.dart';
import 'package:sixam_mart_delivery/features/auth/controllers/auth_controller.dart';
import 'package:sixam_mart_delivery/features/language/widgets/language_bottom_sheet_widget.dart';
import 'package:sixam_mart_delivery/features/profile/controllers/profile_controller.dart';
import 'package:sixam_mart_delivery/features/profile/widgets/notification_status_change_bottom_sheet.dart';
import 'package:sixam_mart_delivery/features/profile/widgets/profile_bg_widget.dart';
import 'package:sixam_mart_delivery/features/profile/widgets/profile_button_widget.dart';
import 'package:sixam_mart_delivery/features/profile/widgets/profile_card_widget.dart';
import 'package:sixam_mart_delivery/features/profile/widgets/profile_level_details_widget.dart';
import 'package:sixam_mart_delivery/features/refer_and_earn/screens/refer_and_earn_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/add_vehicle/screens/vehicle_details_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/leaderboard/screens/leaderboard_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/review/screens/review_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/safety/screen/safety_policy_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/help_and_support/screens/help_and_support_screen.dart';
import 'package:sixam_mart_delivery/features/splash/controllers/splash_controller.dart';
import 'package:sixam_mart_delivery/common/controllers/theme_controller.dart';
import 'package:sixam_mart_delivery/helper/pusher_helper.dart';
import 'package:sixam_mart_delivery/helper/route_helper.dart';
import 'package:sixam_mart_delivery/util/app_constants.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/images.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Rider-specific profile screen.
/// Shows rider stats, vehicle, reviews, leaderboard, safety — no delivery-man items.
class RiderProfileScreen extends StatefulWidget {
  const RiderProfileScreen({super.key});

  @override
  State<RiderProfileScreen> createState() => _RiderProfileScreenState();
}

class _RiderProfileScreenState extends State<RiderProfileScreen> {
  @override
  void initState() {
    super.initState();
    Get.find<ProfileController>().getProfile();
    Get.find<ProfileController>().getProfileLevelInfo();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).cardColor,
      body: GetBuilder<ProfileController>(builder: (profileCtrl) {
        final config = Get.find<SplashController>().configModel;
        final bool showReferAndEarn = profileCtrl.profileModel != null &&
            profileCtrl.profileModel!.earnings == 1 &&
            (config?.riderReferralData?.referalStatus ?? false);

        if (profileCtrl.profileModel == null) {
          return const Center(child: CircularProgressIndicator());
        }

        return ProfileBgWidget(
          backButton: false,
          circularImage: Container(
            decoration: BoxDecoration(
              border: Border.all(width: 2, color: Theme.of(context).cardColor),
              shape: BoxShape.circle,
            ),
            child: Stack(
              alignment: Alignment.bottomCenter,
              clipBehavior: Clip.none,
              children: [
                ClipOval(child: CustomImageWidget(
                  image: profileCtrl.profileModel!.imageFullUrl ?? '',
                  height: 100, width: 100, fit: BoxFit.cover,
                )),
                if (config?.riderLevelStatus == 1)
                  Positioned(
                    bottom: -5,
                    child: InkWell(
                      onTap: () {
                        Get.find<ProfileController>().getProfileLevelInfo();
                        Get.bottomSheet(const ProfileLevelDetailsWidget());
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
                        decoration: BoxDecoration(
                          color: Colors.orange,
                          borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
                          boxShadow: [BoxShadow(
                            color: Colors.grey[Get.isDarkMode ? 850 : 200]!,
                            spreadRadius: 1, blurRadius: 5,
                          )],
                        ),
                        child: Text(
                          profileCtrl.levelModel?.data?.currentLevel?.name ?? '',
                          style: robotoRegular.copyWith(
                              color: Theme.of(context).cardColor, fontSize: 12),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          mainWidget: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Center(child: Container(
              width: 1170,
              color: Theme.of(context).cardColor,
              padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
              child: Column(children: [

                // Name
                Text(
                  '${profileCtrl.profileModel!.fName} ${profileCtrl.profileModel!.lName}',
                  style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeLarge),
                ),
                const SizedBox(height: 5),

                // Rating
                Row(mainAxisSize: MainAxisSize.min, children: [
                  Text('${profileCtrl.profileModel!.avgRating ?? 0} '),
                  const Icon(Icons.star_rounded, color: Colors.orange, size: 16),
                  Text(
                    '(${'reviews'.tr} ${profileCtrl.profileModel?.ratingCount ?? 0})',
                    style: robotoRegular.copyWith(
                        color: Theme.of(context).hintColor.withValues(alpha: 0.5)),
                  ),
                ]),
                const SizedBox(height: 15),

                // Stats cards
                Row(children: [
                  ProfileCardWidget(
                    title: 'days_since_joining'.tr,
                    data: '${profileCtrl.profileModel!.memberSinceDays ?? 0}',
                  ),
                  const SizedBox(width: Dimensions.paddingSizeSmall),
                  ProfileCardWidget(
                    title: 'total_ride'.tr,
                    data: '${profileCtrl.profileModel!.totalRides ?? 0}',
                  ),
                ]),
                const SizedBox(height: 30),

                // Online toggle
                _OnlineToggleRow(profileCtrl: profileCtrl),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Dark mode
                ProfileButtonWidget(
                  icon: Icons.dark_mode_outlined,
                  title: 'dark_mode'.tr,
                  isButtonActive: Get.isDarkMode,
                  onTap: () => Get.find<ThemeController>().toggleTheme(),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Notifications
                GetBuilder<AuthController>(builder: (authCtrl) {
                  return ProfileButtonWidget(
                    iconImage: Images.settingIcon,
                    title: 'system_notification'.tr,
                    isButtonActive: authCtrl.notification,
                    onTap: () => showCustomBottomSheet(
                        child: const NotificationStatusChangeBottomSheet()),
                  );
                }),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Vehicle details
                if (profileCtrl.profileModel?.vehicle != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                    child: ProfileButtonWidget(
                      iconImage: Images.car,
                      title: 'vehicle_details'.tr,
                      onTap: () => Get.to(() => VehicleDetailsScreen()),
                    ),
                  ),

                // Change password
                ProfileButtonWidget(
                  iconImage: Images.security,
                  title: 'change_password'.tr,
                  onTap: () => Get.toNamed(
                      RouteHelper.getResetPasswordRoute('', '', 'password-change')),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Language
                ProfileButtonWidget(
                  iconImage: Images.translation,
                  title: 'language'.tr,
                  onTap: () => _changeLanguage(),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Edit profile
                ProfileButtonWidget(
                  iconImage: Images.editUser,
                  title: 'edit_profile'.tr,
                  onTap: () => Get.toNamed(RouteHelper.getUpdateProfileRoute()),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Reviews
                Padding(
                  padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                  child: ProfileButtonWidget(
                    iconImage: Images.noReview,
                    title: 'my_reviews'.tr,
                    onTap: () => Get.to(() => const ReviewScreen()),
                  ),
                ),

                // Leaderboard
                Padding(
                  padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                  child: ProfileButtonWidget(
                    iconImage: Images.leaderBoardIcon,
                    title: 'leader_board'.tr,
                    onTap: () => Get.to(() => const LeaderboardScreen()),
                  ),
                ),

                // Help & support
                ProfileButtonWidget(
                  iconImage: Images.support,
                  title: 'help_and_support'.tr,
                  onTap: () => Get.to(() => const HelpAndSupportScreen()),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Earnings (if enabled)
                if (profileCtrl.profileModel!.earnings == 1) ...[
                  Padding(
                    padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                    child: ProfileButtonWidget(
                      iconImage: Images.earning,
                      title: 'my_earning'.tr,
                      onTap: () => Get.toNamed(RouteHelper.getMyEarningRoute()),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                    child: ProfileButtonWidget(
                      iconImage: Images.earningReport,
                      title: 'earning_report'.tr,
                      onTap: () => Get.toNamed(RouteHelper.getEarningReportRoute()),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                    child: ProfileButtonWidget(
                      iconImage: Images.emptyWallet,
                      title: 'my_account'.tr,
                      onTap: () => Get.toNamed(RouteHelper.getMyAccountRoute()),
                    ),
                  ),
                ],

                // Withdraw
                Padding(
                  padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                  child: ProfileButtonWidget(
                    icon: Icons.money,
                    title: 'withdraw_method'.tr,
                    onTap: () => Get.toNamed(RouteHelper.getWithdrawMethodRoute()),
                  ),
                ),

                // Refer & earn
                if (showReferAndEarn)
                  Padding(
                    padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                    child: ProfileButtonWidget(
                      iconImage: Images.earning,
                      title: 'refer_and_earn'.tr,
                      onTap: () => Get.to(() => const ReferAndEarnScreen()),
                    ),
                  ),

                // Safety
                Padding(
                  padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
                  child: ProfileButtonWidget(
                    iconImage: Images.shieldTick,
                    title: 'safety'.tr,
                    onTap: () => Get.to(() => const SafetyPolicyScreen()),
                  ),
                ),

                // Terms & privacy
                ProfileButtonWidget(
                  iconImage: Images.document,
                  title: 'terms_condition'.tr,
                  onTap: () => Get.toNamed(RouteHelper.getTermsRoute()),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                ProfileButtonWidget(
                  iconImage: Images.document,
                  title: 'privacy_policy'.tr,
                  onTap: () => Get.toNamed(RouteHelper.getPrivacyRoute()),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Delete account
                ProfileButtonWidget(
                  iconImage: Images.trash,
                  title: 'delete_account'.tr,
                  onTap: () => Get.dialog(ConfirmationDialogWidget(
                    icon: Images.warning,
                    title: 'are_you_sure_to_delete_account'.tr,
                    description: 'it_will_remove_your_all_information'.tr,
                    isLogOut: true,
                    onYesPressed: () => profileCtrl.deleteDriver(),
                  ), useSafeArea: false),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // Logout
                ProfileButtonWidget(
                  icon: Icons.logout,
                  title: 'logout'.tr,
                  onTap: () {
                    Get.back();
                    Get.dialog(ConfirmationDialogWidget(
                      icon: Images.support,
                      description: 'are_you_sure_to_logout'.tr,
                      isLogOut: true,
                      onYesPressed: () {
                        PusherHelper().pusherDisconnectPusher();
                        Get.find<AuthController>().clearSharedData();
                        Get.find<ProfileController>().stopLocationRecord();
                        Get.offAllNamed(RouteHelper.getSignInRoute());
                      },
                    ));
                  },
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                // Version
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('${'version'.tr}:',
                      style: robotoRegular.copyWith(
                          fontSize: Dimensions.fontSizeExtraSmall)),
                  const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                  Text(AppConstants.appVersion.toString(),
                      style: robotoMedium.copyWith(
                          fontSize: Dimensions.fontSizeExtraSmall)),
                ]),

              ]),
            )),
          ),
        );
      }),
    );
  }

  void _changeLanguage() {
    Get.bottomSheet(
      const LanguageBottomSheetWidget(),
      isScrollControlled: true,
    );
  }
}

// ── Online toggle row ──────────────────────────────────────────────────────

class _OnlineToggleRow extends StatelessWidget {
  final ProfileController profileCtrl;
  const _OnlineToggleRow({required this.profileCtrl});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: Dimensions.paddingSizeSmall,
        vertical: Dimensions.paddingSizeExtraSmall,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(5),
        boxShadow: [BoxShadow(
          color: Colors.grey[Get.isDarkMode ? 850 : 200]!,
          spreadRadius: 1, blurRadius: 5,
        )],
      ),
      child: Row(children: [
        Image.asset(Images.online, height: 25, width: 25,
            color: Theme.of(context).disabledColor),
        const SizedBox(width: Dimensions.paddingSizeSmall),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('online_status'.tr, style: robotoRegular),
          Text('manage_your_delivery_availability'.tr,
              style: robotoRegular.copyWith(
                fontSize: Dimensions.fontSizeSmall,
                color: Theme.of(context).disabledColor,
              )),
        ])),
        GetBuilder<RideController>(builder: (rideCtrl) {
          final bool hasRunningRide = rideCtrl.lastRideDetails?.isNotEmpty == true &&
              rideCtrl.lastRideDetails!.first.currentStatus != 'completed' &&
              rideCtrl.lastRideDetails!.first.currentStatus != 'cancelled';

          return Transform.scale(
            scale: 0.7,
            child: CupertinoSwitch(
              value: profileCtrl.profileModel!.active == 1,
              activeTrackColor: Theme.of(context).primaryColor,
              inactiveTrackColor:
                  Theme.of(context).primaryColor.withValues(alpha: 0.5),
              onChanged: (isActive) async {
                if (!isActive && hasRunningRide) {
                  showCustomBottomSheet(child: CustomConfirmationBottomSheet(
                    title: 'you_cant_go_offline'.tr,
                    description: 'you_can_not_go_offline_now_for_ride'.tr,
                    buttonWidget: Padding(
                      padding: const EdgeInsets.only(bottom: 20, top: 10),
                      child: CustomButtonWidget(
                        width: 150,
                        onPressed: () => Get.back(),
                        buttonText: 'okay'.tr,
                      ),
                    ),
                  ));
                } else {
                  profileCtrl.updateActiveStatus();
                }
              },
            ),
          );
        }),
      ]),
    );
  }
}
