package com.aurasure.vendor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
