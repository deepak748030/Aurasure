import 'dart:convert';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/trip_details_model.dart';

/// Safely maps our backend's Ride entity JSON to the existing [RideDetails]
/// model without crashing on missing legacy fields.
///
/// The existing [RideDetails.fromJson] was written for a different backend
/// and calls `.toString()` / `.toDouble()` on fields that may be null in
/// our backend's response, causing a NoSuchMethodError.
///
/// This adapter normalises the JSON before passing it to [RideDetails.fromJson].
class RideJsonAdapter {
  /// Converts a backend Ride JSON map to a [RideDetails] instance safely.
  static RideDetails fromRideJson(Map<String, dynamic> raw) {
    // Build a normalised map that satisfies all the non-null assumptions
    // in the existing RideDetails.fromJson.
    final json = <String, dynamic>{
      // Core identity
      'id': raw['id']?.toString(),
      'ref_id': raw['reference'],
      'current_status': raw['status'] ?? raw['current_status'],

      // Addresses
      'pickup_address': raw['pickup_address'],
      'destination_address': raw['drop_address'] ?? raw['destination_address'],

      // Coordinates — backend stores as flat lat/lng, not GeoJSON
      'pickup_coordinates': raw['pickup_lat'] != null
          ? {
              'type': 'Point',
              'coordinates': [
                _toDouble(raw['pickup_lng']),
                _toDouble(raw['pickup_lat']),
              ]
            }
          : null,
      'destination_coordinates': raw['drop_lat'] != null
          ? {
              'type': 'Point',
              'coordinates': [
                _toDouble(raw['drop_lng']),
                _toDouble(raw['drop_lat']),
              ]
            }
          : null,

      // Fare fields — use safe defaults so .toString() never crashes
      'estimated_fare': (raw['total_amount'] ?? raw['estimated_fare'] ?? 0).toString(),
      'org_est_fare': '0',
      'estimated_time': (raw['estimated_duration_min'] ?? 0).toString(),
      'estimated_distance': _toDouble(raw['estimated_distance_km']),
      'actual_fare': _toDouble(raw['total_amount']),
      'actual_time': _toDouble(raw['actual_duration_min']),
      'actual_distance': _toDouble(raw['actual_distance_km']),
      'total_fare': (raw['total_amount'] ?? 0).toString(),
      'paid_fare': _toDouble(raw['paid_fare'] ?? raw['total_amount']),

      // Legacy fields that must not be null for .toString() calls
      'waiting_time': '0',
      'idle_time': '0',
      'additional_charge': '0',
      'due_amount': 0.0,

      // Payment
      'payment_method': raw['payment_method'],
      'payment_status': raw['payment_status'],

      // Discount / coupon
      'coupon_amount': _toDouble(raw['coupon_discount']),
      'discount_amount': _toDouble(raw['discount_amount']),
      'vat_tax': _toDouble(raw['tax_amount']),

      // OTP
      'otp': raw['otp'],

      // Timestamps
      'created_at': raw['created_at'],
      'ride_start_time': raw['started_at'],
      'ride_complete_time': raw['completed_at'],

      // Customer — map from user_contact_json if present
      'customer': _buildCustomer(raw),

      // Vehicle type
      'vehicle_category': raw['vehicle_type'] != null
          ? {
              'id': raw['vehicle_type']['id']?.toString(),
              'name': raw['vehicle_type']['name'],
              'image': raw['vehicle_type']['icon'],
              'type': 'ride',
            }
          : null,

      // Nulls for fields the model expects but we don't have
      'vehicle': null,
      'customer_request_coordinates': null,
      'note': null,
      'rise_request_count': null,
      'type': 'ride',
      'completed': null,
      'entrance': null,
      'intermediate_addresses': null,
      'encoded_polyline': null,
      'customer_avg_rating': '0',
      'driver_avg_rating': null,
      'tripStatus': null,
      'parcel_information': null,
      'parcel_user_info': null,
      'fare_biddings': null,
      'screenshot': null,
      'is_paused': false,
      'is_reached_destination': false,
      'customer_review': false,
      'admin_commission': _toDouble(raw['admin_commission']),
      'return_fee': 0.0,
      'return_time': null,
      'parcel_refund': null,
      'driver_safety_alert': null,
      'customer_safety_alert': null,
      'parcel_start_time': null,
      'parcel_complete_time': null,
      'scheduled_at': raw['scheduled_at'],
    };

    return RideDetails.fromJson(json);
  }

  static Map<String, dynamic>? _buildCustomer(Map<String, dynamic> raw) {
    // Backend stores customer contact in user_contact_json as a JSON string.
    // FIX Issue #9: decode the string before treating it as a map.
    final contactRaw = raw['user_contact_json'];
    Map<String, dynamic> c = {};
    if (contactRaw is String && contactRaw.isNotEmpty) {
      try {
        final decoded = jsonDecode(contactRaw);
        if (decoded is Map) c = Map<String, dynamic>.from(decoded);
      } catch (_) {}
    } else if (contactRaw is Map) {
      c = Map<String, dynamic>.from(contactRaw);
    }
    if (c.isEmpty && raw['user_id'] == null) return null;
    return {
      'id': raw['user_id']?.toString(),
      'first_name': c['name'] ?? '',
      'last_name': '',
      'email': c['email'] ?? '',
      'phone': c['phone'] ?? '',
      'identification_number': null,
      'identification_type': null,
      'identification_image': <String>[],
      'profile_image': null,
      'user_rating': 0,
    };
  }

  static double _toDouble(dynamic v) {
    if (v == null) return 0.0;
    if (v is double) return v;
    if (v is int) return v.toDouble();
    return double.tryParse(v.toString()) ?? 0.0;
  }
}
