import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/screens/ride_details_screen.dart';

/// Shows completed ride history.
class OngoingRideListScreen extends StatefulWidget {
  const OngoingRideListScreen({super.key});

  @override
  State<OngoingRideListScreen> createState() => _OngoingRideListScreenState();
}

class _OngoingRideListScreenState extends State<OngoingRideListScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.find<RideController>().ongoingTripList();
    });
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('My Rides',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        backgroundColor: Theme.of(context).cardColor,
        foregroundColor: Theme.of(context).textTheme.bodyLarge?.color,
        elevation: 0,
        bottom: TabBar(
          controller: _tabCtrl,
          labelColor: Theme.of(context).primaryColor,
          unselectedLabelColor: Theme.of(context).disabledColor,
          indicatorColor: Theme.of(context).primaryColor,
          tabs: const [
            Tab(text: 'Active'),
            Tab(text: 'Completed'),
          ],
        ),
      ),
      body: GetBuilder<RideController>(builder: (ctrl) {
        return TabBarView(
          controller: _tabCtrl,
          children: [
            // Active rides
            _RideList(
              rides: ctrl.ongoingRide ?? [],
              isLoading: ctrl.isLoading,
              emptyMessage: 'No active rides',
            ),
            // Completed rides (last ride details)
            _RideList(
              rides: ctrl.lastRideDetails ?? [],
              isLoading: ctrl.isLoading,
              emptyMessage: 'No completed rides yet',
            ),
          ],
        );
      }),
    );
  }
}

class _RideList extends StatelessWidget {
  final List rides;
  final bool isLoading;
  final String emptyMessage;

  const _RideList({
    required this.rides,
    required this.isLoading,
    required this.emptyMessage,
  });

  @override
  Widget build(BuildContext context) {
    if (isLoading && rides.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (rides.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.history, size: 56, color: Color(0xFFCCCCCC)),
            const SizedBox(height: 12),
            Text(emptyMessage,
                style: const TextStyle(
                    fontSize: 15, color: Color(0xFF888888))),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: rides.length,
      itemBuilder: (_, i) {
        final ride = rides[i];
        return GestureDetector(
          onTap: () => Get.to(() => RideDetailsScreen(ride: ride)),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.06),
                    blurRadius: 8,
                    offset: const Offset(0, 2)),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(Icons.directions_car,
                      size: 22, color: Theme.of(context).primaryColor),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        ride.destinationAddress ?? 'Destination',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: Theme.of(context).textTheme.bodyLarge?.color),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        ride.createdAt ?? '',
                        style: TextStyle(
                            fontSize: 12, color: Theme.of(context).disabledColor),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '₹${ride.totalFare ?? ride.paidFare?.toStringAsFixed(2) ?? '0'}',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Theme.of(context).textTheme.bodyLarge?.color),
                    ),
                    const SizedBox(height: 3),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: _statusColor(ride.currentStatus ?? '')
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        (ride.currentStatus ?? '').replaceAll('_', ' '),
                        style: TextStyle(
                            fontSize: 10,
                            color: _statusColor(ride.currentStatus ?? ''),
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 4),
                Icon(Icons.chevron_right,
                    size: 18, color: Theme.of(context).disabledColor),
              ],
            ),
          ),
        );
      },
    );
  }

  Color _statusColor(String status) {
    final context = Get.context!;
    switch (status) {
      case 'completed': return Theme.of(context).primaryColor;
      case 'cancelled': return Colors.red;
      case 'in_progress': return Theme.of(context).colorScheme.error;
      default: return Theme.of(context).primaryColor;
    }
  }
}

/// Legacy alias — notification_helper.dart and pusher_helper.dart use
/// `const OngoingRideScreen()`.  A typedef cannot be const-constructed when
/// the target is a StatefulWidget, so we use a thin const-constructible
/// StatelessWidget wrapper instead.
class OngoingRideScreen extends StatelessWidget {
  const OngoingRideScreen({super.key});

  @override
  Widget build(BuildContext context) => const OngoingRideListScreen();
}
