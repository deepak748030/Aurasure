import 'dart:convert';
import 'dart:developer';
import 'package:audioplayers/audioplayers.dart';
import 'package:dart_pusher_channels/dart_pusher_channels.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/map/controllers/ride_map_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/screens/ride_details_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/safety/controllers/safety_alert_controller.dart';
import 'package:sixam_mart_delivery/features/splash/controllers/splash_controller.dart';
import 'package:sixam_mart_delivery/helper/ride_helper.dart';
import 'package:sixam_mart_delivery/util/app_constants.dart';

/// PusherHelper — real-time WebSocket integration for the RideShare module.
///
/// Backend channel definitions (Modules/RideShare/Routes/channels.php):
///   driver.{driverId}   — driver's own offer queue + ongoing ride events
///   ride.{rideId}       — both participants + admin observers
///   rider.{userId}      — rider's own ride updates
///   zone.{zoneId}       — admin fleet-map overlay
///   safety-alerts       — admin safety alert bell
///
/// Backend events (Modules/RideShare/Events/):
///   ride.status.changed     — RideStatusChanged (driver, ride, rider, zone channels)
///   driver.location.updated — DriverLocationUpdated (driver, ride, zone channels)
///   safety.alert.raised     — SafetyAlertRaised (safety-alerts channel)
///
/// New ride offers are delivered via FCM push (not Pusher) — see RidePushNotification trait.
/// Pusher is used only for in-trip real-time updates after a ride is accepted.
class PusherHelper {
  static PusherChannelsClient? pusherClient;

  // ── Connection ──────────────────────────────────────────────────────────

  static Future<void> initializePusher() async {
    final config = Get.find<SplashController>().configModel;
    if (config == null || !(config.webSocketStatus ?? false)) return;

    final options = PusherChannelsOptions.fromHost(
      host: config.webSocketUri
              ?.replaceAll('wss://', '')
              .replaceAll('ws://', '') ??
          '',
      scheme: config.websocketScheme == 'https' ? 'wss' : 'ws',
      key: config.webSocketKey ?? '',
      port: config.webSocketPort ?? 6001,
    );

    pusherClient = PusherChannelsClient.websocket(
      options: options,
      connectionErrorHandler: (exception, trace, refresh) async {
        log('Pusher error: $exception');
        Get.find<SplashController>().setPusherStatus('Disconnected');
        refresh();
      },
    );
    await pusherClient?.connect();

    final socketId =
        pusherClient?.channelsManager.channelsConnectionDelegate.socketId;
    if (socketId != null) {
      if (kDebugMode) print('Pusher connected — socket: $socketId');
      Get.find<SplashController>().setPusherStatus('Connected');
    }

    pusherClient?.lifecycleStream.listen((_) {
      Get.find<SplashController>().setPusherStatus('Disconnected');
    });
  }

  static bool get _isConnected =>
      Get.find<SplashController>().pusherConnectionStatus == 'Connected';

  // ── Helper: build a public channel (no auth needed — backend uses public channels) ──

  static Channel _publicChannel(String name) =>
      pusherClient!.publicChannel(name);

  // ── Driver channel — driver.{driverId} ─────────────────────────────────
  //
  // Receives:
  //   ride.status.changed  — new offer dispatched, ride accepted by another driver,
  //                          ride cancelled, payment confirmed, etc.
  //   driver.location.updated — echo of own location (optional, for debug)

  Channel? _driverChannel;

  void subscribeDriverChannel(String driverId) {
    if (!_isConnected || pusherClient == null) return;

    _driverChannel = _publicChannel('driver.$driverId');

    // ride.status.changed — covers all ride lifecycle events for this driver
    _driverChannel!.bind('ride.status.changed').listen((event) {
      if (kDebugMode) print('driver.$driverId → ride.status.changed: ${event.data}');
      _handleRideStatusChanged(event.data);
    });
  }

  // ── Ride channel — ride.{rideId} ────────────────────────────────────────
  //
  // Receives:
  //   ride.status.changed      — status transitions (accepted → arriving → arrived → in_progress → completed)
  //   driver.location.updated  — driver GPS for the in-trip map

  Channel? _rideChannel;

  void subscribeRideChannel(String rideId) {
    if (!_isConnected || pusherClient == null) return;

    _rideChannel = _publicChannel('ride.$rideId');

    _rideChannel!.bind('ride.status.changed').listen((event) {
      if (kDebugMode) print('ride.$rideId → ride.status.changed: ${event.data}');
      _handleRideStatusChanged(event.data);
    });

    _rideChannel!.bind('driver.location.updated').listen((event) {
      if (kDebugMode) print('ride.$rideId → driver.location.updated');
      // Location updates are handled by the map controller directly via polling
      // or via this event — update the map marker.
      try {
        final data = _decode(event.data);
        if (data != null) {
          Get.find<RiderMapController>().updateDriverLocationFromPusher(
            lat: (data['latitude'] as num?)?.toDouble() ?? 0,
            lng: (data['longitude'] as num?)?.toDouble() ?? 0,
            heading: (data['heading'] as num?)?.toDouble(),
          );
        }
      } catch (_) {}
    });
  }

  void unsubscribeRideChannel() {
    _rideChannel = null;
  }

  // ── Status change handler ───────────────────────────────────────────────

  void _handleRideStatusChanged(String? rawData) {
    final data = _decode(rawData);
    if (data == null) return;

    final status = data['current_status'] as String?;
    final rideId = data['id']?.toString();

    if (status == null || rideId == null) return;

    switch (status) {
      // New offer dispatched to this driver — handled by FCM push.
      // Pusher is a fallback when FCM is delayed.
      case 'searching':
        Get.find<RideController>().getPendingRideRequestList(1);
        AudioPlayer().play(AssetSource('notification.mp3'));
        break;

      // Another driver accepted — clear this driver's pending offer.
      case 'accepted':
        // If this driver's current trip detail doesn't match the accepted ride,
        // another driver got it — clear pending state.
        final currentRideId = Get.find<RideController>().tripDetail?.id;
        if (currentRideId != rideId) {
          Get.find<RideController>().getPendingRideRequestList(1);
          Get.find<RiderMapController>().setRideCurrentState(RideState.initial);
        }
        break;

      // Customer cancelled before/during ride.
      case 'cancelled':
        Get.find<SafetyAlertController>().cancelDriverNeedSafetyStream();
        Get.find<RideController>().tripDetail = null;
        Get.find<RideController>().getPendingRideRequestList(1).then((_) {
          Get.find<RiderMapController>().setRideCurrentState(RideState.initial);
          Get.find<RideController>().getLastRideDetail();
        });
        break;

      // Ride completed — navigate to details.
      case 'completed':
        Get.find<SafetyAlertController>().cancelDriverNeedSafetyStream();
        RideHelper.navigateToNextScreen(id: rideId);
        break;

      // Payment confirmed after completion.
      case 'paid':
        Get.find<RideController>().ongoingTripList().then((value) {
          if ((Get.find<RideController>().ongoingRide ?? []).isEmpty) {
            RideHelper.navigateToNextScreen(id: rideId);
          }
        });
        break;

      // Payment failed — show details screen.
      case 'payment_failed':
        Get.offAll(() => RideDetailsScreen(rideId: rideId));
        break;

      default:
        // For arriving, arrived, in_progress — refresh ride detail.
        Get.find<RideController>().getRideDetails(rideId);
        break;
    }
  }

  // ── Disconnect ──────────────────────────────────────────────────────────

  void pusherDisconnectPusher() {
    pusherClient?.disconnect();
  }

  // ── Driver trip-request subscription ───────────────────────────────────
  /// Called from ProfileController after login to subscribe to the driver's
  /// own channel so new ride offers arrive in real-time.
  void driverTripRequestSubscribe(String driverId) {
    subscribeDriverChannel(driverId);
  }

  // ── Static location broadcast via Pusher ────────────────────────────────
  /// Broadcasts the driver's current location over the active ride channel.
  /// Falls back silently if Pusher is not connected.
  static void recordLocationViaPusher({
    required String token,
    required double latitude,
    required double longitude,
    required String location,
  }) {
    if (!_isConnected || pusherClient == null) return;
    // Location is broadcast server-side via the backend's DriverLocationUpdated event.
    // This client-side call is a no-op placeholder — the backend receives location
    // via the REST recordLocationUri and then broadcasts to Pusher itself.
    // Kept here so profile_repository.dart compiles without changes.
  }

  // ── Utility ─────────────────────────────────────────────────────────────

  Map<String, dynamic>? _decode(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    try {
      return jsonDecode(raw) as Map<String, dynamic>?;
    } catch (_) {
      return null;
    }
  }
}
