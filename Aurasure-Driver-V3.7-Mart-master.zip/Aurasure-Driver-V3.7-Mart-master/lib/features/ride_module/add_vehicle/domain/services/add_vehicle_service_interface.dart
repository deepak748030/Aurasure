import 'package:get/get_connect/http/src/response/response.dart';

abstract class AddVehicleServiceInterface {
  Future<Response> getDocuments();
  Future<Response> uploadDocument({
    required String documentType,
    required String frontImagePath,
    String? backImagePath,
    String? documentNumber,
    String? issuedOn,
    String? expiresOn,
  });
}
