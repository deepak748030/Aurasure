import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/review/controllers/review_controller.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Driver reviews screen — shows the driver's average rating and review count.
/// Full review list requires a dedicated reviews API endpoint.
class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.find<ReviewController>().loadRating();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        elevation: 0,
        title: Text('my_reviews'.tr,
            style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: GetBuilder<ReviewController>(builder: (ctrl) {
        if (ctrl.isLoading && ctrl.ratingCount == 0 && ctrl.avgRating == 0) {
          return const Center(child: CircularProgressIndicator());
        }

        final double rating = ctrl.avgRating;
        final int count = ctrl.ratingCount;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
          child: Column(children: [

            // ── Rating summary card ───────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                boxShadow: [BoxShadow(
                  color: Theme.of(context).disabledColor.withValues(alpha: 0.12),
                  blurRadius: 10,
                )],
              ),
              child: Column(children: [
                Text(
                  rating.toStringAsFixed(1),
                  style: robotoBold.copyWith(fontSize: 56, color: Theme.of(context).primaryColor),
                ),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  ...List.generate(5, (i) => Icon(
                    i < rating.round() ? Icons.star_rounded : Icons.star_outline_rounded,
                    color: Colors.amber, size: 28,
                  )),
                ]),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                Text(
                  '$count ${'reviews'.tr}',
                  style: robotoRegular.copyWith(
                    color: Theme.of(context).disabledColor,
                    fontSize: Dimensions.fontSizeDefault,
                  ),
                ),
              ]),
            ),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            // ── Empty state ───────────────────────────────────────────
            if (count == 0)
              Column(children: [
                Icon(Icons.rate_review_outlined, size: 64,
                    color: Theme.of(context).disabledColor),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                Text('no_reviews_yet'.tr,
                    style: robotoRegular.copyWith(
                      color: Theme.of(context).disabledColor,
                      fontSize: Dimensions.fontSizeDefault,
                    )),
              ]),

          ]),
        );
      }),
    );
  }
}
