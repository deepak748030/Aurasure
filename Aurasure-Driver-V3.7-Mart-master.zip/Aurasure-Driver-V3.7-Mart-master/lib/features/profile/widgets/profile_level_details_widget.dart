import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/profile/controllers/profile_controller.dart';
import 'package:sixam_mart_delivery/features/profile/domain/models/level_model.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Bottom sheet showing the driver's current level, next level, and progress.
/// Driven by [ProfileController.levelModel].
class ProfileLevelDetailsWidget extends StatelessWidget {
  const ProfileLevelDetailsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(Dimensions.radiusLarge),
        ),
      ),
      padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
      child: GetBuilder<ProfileController>(builder: (ctrl) {
        if (ctrl.levelModel?.data == null) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeLarge),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.emoji_events_outlined,
                  size: 48, color: Theme.of(context).disabledColor),
              const SizedBox(height: Dimensions.paddingSizeSmall),
              Text('no_levels_available'.tr,
                  style: robotoMedium.copyWith(
                    color: Theme.of(context).disabledColor,
                  )),
            ]),
          );
        }

        final Data? data = ctrl.levelModel!.data;
        final CurrentLevel? current = data?.currentLevel;
        final NextLevel? next = data?.nextLevel;
        final CompletedCurrentLevelTarget? done = data?.completedCurrentLevelTarget;

        return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(
            child: Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: Theme.of(context).disabledColor.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: Dimensions.paddingSizeLarge),

          Row(children: [
            const Icon(Icons.emoji_events_rounded, color: Colors.orange),
            const SizedBox(width: Dimensions.paddingSizeSmall),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('current_level'.tr,
                  style: robotoRegular.copyWith(
                    fontSize: Dimensions.fontSizeSmall,
                    color: Theme.of(context).disabledColor,
                  )),
              Text(current?.name ?? '-',
                  style: robotoBold.copyWith(
                    fontSize: Dimensions.fontSizeLarge,
                    color: Colors.orange,
                  )),
            ]),
          ]),
          const SizedBox(height: Dimensions.paddingSizeLarge),

          if (current != null && done != null) ...[
            _row(context, 'rides_completed'.tr, done.rideComplete ?? 0, current.targetedRide ?? 0),
            _row(context, 'earning_amount'.tr, done.earningAmount ?? 0, current.targetedAmount ?? 0),
            _row(context, 'reviews_given'.tr, done.reviewGiven ?? 0, current.targetedReview ?? 0),
          ],

          const SizedBox(height: Dimensions.paddingSizeSmall),
          if (next != null)
            Row(children: [
              const Icon(Icons.arrow_upward_rounded, size: 18),
              const SizedBox(width: Dimensions.paddingSizeExtraSmall),
              Text('${'next_level'.tr}: ${next.name ?? '-'}',
                  style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall)),
            ])
          else
            Text('you_are_at_the_highest_level'.tr,
                style: robotoMedium.copyWith(color: Colors.amber)),
          const SizedBox(height: Dimensions.paddingSizeSmall),
        ]);
      }),
    );
  }

  Widget _row(BuildContext context, String label, double done, double target) {
    final pct = target > 0 ? (done / target).clamp(0.0, 1.0) : 0.0;
    return Padding(
      padding: const EdgeInsets.only(bottom: Dimensions.paddingSizeDefault),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall)),
          Text('${done.toStringAsFixed(0)} / ${target.toStringAsFixed(0)}',
              style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall)),
        ]),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: pct,
            minHeight: 8,
            backgroundColor: Theme.of(context).disabledColor.withValues(alpha: 0.15),
            valueColor: AlwaysStoppedAnimation(Theme.of(context).primaryColor),
          ),
        ),
      ]),
    );
  }
}
