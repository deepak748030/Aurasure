import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/ride_json_adapter.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/trip_details_model.dart';

/// Shows full details of a ride.
///
/// Accepts either:
///   - a pre-loaded [ride] object (from list screens), OR
///   - a [rideId] string (from notifications / deep links) — the screen
///     fetches the ride details itself.
///
/// Also accepts legacy params [rideDetails] and [fromListScreen] so that
/// existing callers in notification_helper.dart and ride_helper.dart
/// continue to compile without modification.
class RideDetailsScreen extends StatefulWidget {
  /// Pre-loaded ride object — used when navigating from a list screen.
  final RideDetails? ride;

  /// Ride ID string — used when navigating from a notification.
  /// If provided and [ride] is null, the screen fetches details on init.
  final String? rideId;

  /// Legacy alias for [ride] — accepted so existing callers compile.
  final RideDetails? rideDetails;

  /// Legacy param — accepted but unused in this implementation.
  final bool fromListScreen;

  const RideDetailsScreen({
    super.key,
    this.ride,
    this.rideId,
    this.rideDetails,
    this.fromListScreen = false,
  });

  @override
  State<RideDetailsScreen> createState() => _RideDetailsScreenState();
}

class _RideDetailsScreenState extends State<RideDetailsScreen> {
  RideDetails? _ride;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    // Priority: ride > rideDetails > fetch by rideId
    _ride = widget.ride ?? widget.rideDetails;
    if (_ride == null && (widget.rideId ?? '').isNotEmpty) {
      _fetchById(widget.rideId!);
    }
  }

  Future<void> _fetchById(String id) async {
    setState(() => _loading = true);
    final rd = await Get.find<RideController>().getRideDetails(id);
    if (mounted) setState(() { _ride = rd; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final ride = _ride;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Ride #${ride?.refId ?? ride?.id ?? widget.rideId ?? ''}',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        backgroundColor: Theme.of(context).cardColor,
        foregroundColor: Theme.of(context).textTheme.bodyLarge?.color,
        elevation: 0,
      ),
      body: ride == null
          ? Center(
              child: Text('no_data_found'.tr,
                  style: const TextStyle(
                      fontSize: 15, color: Color(0xFF888888))),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // ── Status badge ──────────────────────────────────────
                  _StatusBadge(status: ride.currentStatus ?? ''),
                  const SizedBox(height: 16),

                  // ── Route card ────────────────────────────────────────
                  _Card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const _SectionTitle('Route'),
                        const SizedBox(height: 12),
                        _RouteItem(
                          icon: Icons.circle,
                          iconColor: Theme.of(context).primaryColor,
                          label: ride.pickupAddress ?? 'Pickup',
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 7),
                          child: SizedBox(
                            width: 1.5,
                            height: 20,
                            child: ColoredBox(color: Theme.of(context).dividerTheme.color ?? Colors.grey.shade300),
                          ),
                        ),
                        _RouteItem(
                          icon: Icons.square,
                          iconColor: Theme.of(context).primaryColor,
                          label: ride.destinationAddress ?? 'Destination',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ── Fare breakdown ────────────────────────────────────
                  _Card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const _SectionTitle('Fare Breakdown'),
                        const SizedBox(height: 12),
                        _FareRow('Estimated Fare',
                            '₹${ride.estimatedFare ?? '0'}'),
                        if ((ride.actualFare ?? 0) > 0)
                          _FareRow('Actual Fare',
                              '₹${ride.actualFare?.toStringAsFixed(2)}'),
                        if ((ride.couponAmount ?? 0) > 0)
                          _FareRow(
                            'Coupon Discount',
                            '-₹${ride.couponAmount?.toStringAsFixed(2)}',
                            valueColor: Colors.green,
                          ),
                        if ((ride.vatTax ?? 0) > 0)
                          _FareRow('Tax',
                              '₹${ride.vatTax?.toStringAsFixed(2)}'),
                        Divider(
                            height: 20, color: Theme.of(context).dividerTheme.color ?? Colors.grey.shade300),
                        _FareRow(
                          'Total',
                          '₹${ride.totalFare ?? ride.paidFare?.toStringAsFixed(2) ?? '0'}',
                          isBold: true,
                        ),
                        const SizedBox(height: 4),
                        _FareRow('Payment',
                            ride.paymentMethod ?? 'cash'),
                        _FareRow('Status',
                            ride.paymentStatus ?? 'unpaid'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ── Trip stats ────────────────────────────────────────
                  _Card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const _SectionTitle('Trip Stats'),
                        const SizedBox(height: 12),
                        if (ride.estimatedDistance != null)
                          _FareRow('Est. Distance',
                              '${ride.estimatedDistance?.toStringAsFixed(1)} km'),
                        if (ride.actualDistance != null)
                          _FareRow('Actual Distance',
                              '${ride.actualDistance?.toStringAsFixed(1)} km'),
                        if (ride.estimatedTime != null)
                          _FareRow(
                              'Est. Duration', '${ride.estimatedTime} min'),
                        if (ride.actualTime != null)
                          _FareRow('Actual Duration',
                              '${ride.actualTime?.toStringAsFixed(0)} min'),
                        if (ride.createdAt != null)
                          _FareRow('Requested', ride.createdAt!),
                        if (ride.rideStartTime != null)
                          _FareRow('Started', ride.rideStartTime!),
                        if (ride.rideCompleteTime != null)
                          _FareRow('Completed', ride.rideCompleteTime!),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

// ── Shared widgets ─────────────────────────────────────────────────────────

class _StatusBadge extends StatelessWidget {
  final String status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status) {
      case 'completed':   color = Theme.of(context).primaryColor; break;
      case 'cancelled':   color = Colors.red; break;
      case 'in_progress': color = Theme.of(context).colorScheme.error; break;
      default:            color = Theme.of(context).primaryColor;
    }
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Text(
        status.toUpperCase().replaceAll('_', ' '),
        textAlign: TextAlign.center,
        style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 13,
            letterSpacing: 1),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.06),
              blurRadius: 8,
              offset: const Offset(0, 2)),
        ],
      ),
      child: child,
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Text(title,
        style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
            color: Color(0xFF111111)));
  }
}

class _RouteItem extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  const _RouteItem(
      {required this.icon, required this.iconColor, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 12, color: iconColor),
        const SizedBox(width: 10),
        Expanded(
          child: Text(label,
              style: const TextStyle(
                  fontSize: 13, color: Color(0xFF333333)),
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }
}

class _FareRow extends StatelessWidget {
  final String label;
  final String? value;
  final bool isBold;
  final Color? valueColor;
  const _FareRow(this.label, this.value,
      {this.isBold = false, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 13,
                  color: const Color(0xFF555555),
                  fontWeight:
                      isBold ? FontWeight.bold : FontWeight.normal)),
          Text(value ?? '',
              style: TextStyle(
                  fontSize: 13,
                  color: valueColor ?? const Color(0xFF111111),
                  fontWeight:
                      isBold ? FontWeight.bold : FontWeight.w500)),
        ],
      ),
    );
  }
}
