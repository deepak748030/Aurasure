import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/profile/controllers/profile_controller.dart';
import 'package:sixam_mart_delivery/features/profile/domain/models/profile_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/add_vehicle/screens/add_vehicle_screen.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Shows the driver's current vehicle details.
/// Data comes from ProfileController.profileModel.vehicle.
class VehicleDetailsScreen extends StatelessWidget {
  const VehicleDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        elevation: 0,
        title: Text('vehicle_details'.tr,
            style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: GetBuilder<ProfileController>(builder: (ctrl) {
        final Vehicle? v = ctrl.profileModel?.vehicle;

        if (ctrl.profileModel == null) {
          return const Center(child: CircularProgressIndicator());
        }

        if (v == null) {
          return _EmptyVehicle();
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
          child: Column(children: [

            // ── Status banner ─────────────────────────────────────────
            if (v.vehicleRequestStatus != null)
              _StatusBanner(status: v.vehicleRequestStatus!),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            // ── Vehicle card ──────────────────────────────────────────
            _InfoCard(children: [
              _Row('vehicle_name'.tr,     v.name ?? '-'),
              _Row('brand'.tr,            v.brand?.name ?? '-'),
              _Row('model'.tr,            v.model?.name ?? '-'),
              _Row('category'.tr,         v.category?.name ?? '-'),
              _Row('licence_plate'.tr,    v.licencePlateNumber ?? '-'),
              _Row('vin_number'.tr,       v.vinNumber ?? '-'),
              _Row('transmission'.tr,     v.transmission ?? '-'),
              _Row('fuel_type'.tr,        v.fuelType ?? '-'),
              _Row('ownership'.tr,        v.ownership ?? '-'),
            ]),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            // ── Edit button ───────────────────────────────────────────
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () => Get.to(() => AddVehicleScreen(vehicleInfo: v)),
                icon: const Icon(Icons.edit_outlined, size: 18),
                label: Text('edit'.tr, style: robotoMedium),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Theme.of(context).primaryColor,
                  side: BorderSide(color: Theme.of(context).primaryColor),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                  ),
                ),
              ),
            ),

          ]),
        );
      }),
    );
  }
}

class _EmptyVehicle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.directions_car_outlined, size: 64, color: Theme.of(context).disabledColor),
        const SizedBox(height: Dimensions.paddingSizeSmall),
        Text('no_vehicle_added'.tr,
            style: robotoMedium.copyWith(color: Theme.of(context).disabledColor)),
        const SizedBox(height: Dimensions.paddingSizeLarge),
        ElevatedButton(
          onPressed: () => Get.to(() => const AddVehicleScreen()),
          style: ElevatedButton.styleFrom(
            backgroundColor: Theme.of(context).primaryColor,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
            ),
          ),
          child: Text('add_vehicle_info'.tr, style: robotoMedium),
        ),
      ],
    ));
  }
}

class _StatusBanner extends StatelessWidget {
  final String status;
  const _StatusBanner({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    String label;
    switch (status) {
      case 'approved':
        color = Colors.green; label = 'approved'.tr; break;
      case 'pending':
        color = Colors.orange; label = 'vehicle_approval_pending'.tr; break;
      case 'denied':
        color = Colors.red; label = 'denied'.tr; break;
      default:
        color = Theme.of(context).primaryColor; label = status;
    }
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: Dimensions.paddingSizeDefault,
        vertical: Dimensions.paddingSizeSmall,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        border: Border.all(color: color.withValues(alpha: 0.4)),
      ),
      child: Row(children: [
        Icon(Icons.info_outline, size: 18, color: color),
        const SizedBox(width: Dimensions.paddingSizeSmall),
        Text(label, style: robotoMedium.copyWith(color: color)),
      ]),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final List<Widget> children;
  const _InfoCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        boxShadow: [BoxShadow(
          color: Theme.of(context).disabledColor.withValues(alpha: 0.12),
          blurRadius: 8, offset: const Offset(0, 2),
        )],
      ),
      child: Column(children: children),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  const _Row(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: robotoRegular.copyWith(
                fontSize: Dimensions.fontSizeSmall,
                color: Theme.of(context).disabledColor,
              )),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.end,
                style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall)),
          ),
        ],
      ),
    );
  }
}
