import 'package:get/get_connect/http/src/response/response.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/repositories/ride_order_repository_interface.dart';
import 'ride_order_service_interface.dart';

class RideOrderService implements RideOrderServiceInterface {
  final RideOrderRepositoryInterface rideOrderRepositoryInterface;
  RideOrderService({required this.rideOrderRepositoryInterface});

  @override
  Future<Response> login(String phone, String password) =>
      rideOrderRepositoryInterface.login(phone, password);

  @override
  Future<Response> logout() => rideOrderRepositoryInterface.logout();

  @override
  Future<Response> updateFcmToken(String token) =>
      rideOrderRepositoryInterface.updateFcmToken(token);

  @override
  Future<Response> getProfile() => rideOrderRepositoryInterface.getProfile();

  @override
  Future<Response> toggleOnlineStatus(bool online) =>
      rideOrderRepositoryInterface.toggleOnlineStatus(online);

  @override
  Future<Response> sendHeartbeat() =>
      rideOrderRepositoryInterface.sendHeartbeat();

  @override
  Future<Response> updateLocation({
    required double latitude,
    required double longitude,
    double? heading,
    double? speedKmph,
  }) =>
      rideOrderRepositoryInterface.updateLocation(
        latitude: latitude,
        longitude: longitude,
        heading: heading,
        speedKmph: speedKmph,
      );

  @override
  Future<Response> getRideOffers() =>
      rideOrderRepositoryInterface.getRideOffers();

  @override
  Future<Response> acceptRide(int rideId) =>
      rideOrderRepositoryInterface.acceptRide(rideId);

  @override
  Future<Response> rejectRide(int rideId) =>
      rideOrderRepositoryInterface.rejectRide(rideId);

  @override
  Future<Response> updateRideStatus(int rideId, String newStatus) =>
      rideOrderRepositoryInterface.updateRideStatus(rideId, newStatus);

  @override
  Future<Response> startRide(int rideId, String otp) =>
      rideOrderRepositoryInterface.startRide(rideId, otp);

  @override
  Future<Response> completeRide({
    required int rideId,
    required double actualDistanceKm,
    required double actualDurationMin,
    double waitingMinutes = 0,
    double tollAmount = 0,
  }) =>
      rideOrderRepositoryInterface.completeRide(
        rideId: rideId,
        actualDistanceKm: actualDistanceKm,
        actualDurationMin: actualDurationMin,
        waitingMinutes: waitingMinutes,
        tollAmount: tollAmount,
      );

  @override
  Future<Response> getRideList(String type, {int limit = 20, int offset = 1}) =>
      rideOrderRepositoryInterface.getRideList(type, limit: limit, offset: offset);

  @override
  Future<Response> getEarningSummary() =>
      rideOrderRepositoryInterface.getEarningSummary();

  @override
  Future<Response> getEarningTransactions({int limit = 25, int offset = 1}) =>
      rideOrderRepositoryInterface.getEarningTransactions(
          limit: limit, offset: offset);

  @override
  Future<Response> getDocuments() =>
      rideOrderRepositoryInterface.getDocuments();

  @override
  String? getDriverToken() =>
      rideOrderRepositoryInterface.getDriverToken();

  @override
  Future<void> saveDriverToken(String token) =>
      rideOrderRepositoryInterface.saveDriverToken(token);

  @override
  Future<void> clearDriverToken() =>
      rideOrderRepositoryInterface.clearDriverToken();

  @override
  bool isDriverLoggedIn() =>
      rideOrderRepositoryInterface.isDriverLoggedIn();
}
