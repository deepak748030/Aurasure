import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/screens/pending_ride_list_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/history/screens/rider_history_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/home/screens/rider_home_screen.dart';
import 'package:sixam_mart_delivery/features/ride_module/profile/screens/rider_profile_screen.dart';
import 'package:sixam_mart_delivery/helper/notification_helper.dart';
import 'package:sixam_mart_delivery/main.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/images.dart';
import 'package:sixam_mart_delivery/features/dashboard/widgets/bottom_nav_item_widget.dart';

/// Fully self-contained rider dashboard.
/// Replaces the shared DashboardScreen for ride drivers.
/// 4 tabs: Home | Requests | History | Profile
class RiderDashboardScreen extends StatefulWidget {
  final int pageIndex;
  const RiderDashboardScreen({super.key, this.pageIndex = 0});

  @override
  State<RiderDashboardScreen> createState() => _RiderDashboardScreenState();
}

class _RiderDashboardScreenState extends State<RiderDashboardScreen> {
  late PageController _pageCtrl;
  int _pageIndex = 0;
  bool _canExit = false;
  late StreamSubscription _fcmSub;

  final List<Widget> _screens = [
    const RiderHomeScreen(),
    RideRequestScreen(onTap: null),
    const RiderHistoryScreen(),
    const RiderProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _pageIndex = widget.pageIndex;
    _pageCtrl = PageController(initialPage: widget.pageIndex);

    _fcmSub = FirebaseMessaging.onMessage.listen(_onFcmMessage);
  }

  void _onFcmMessage(RemoteMessage message) {
    final type = message.data['body_loc_key'] ?? message.data['type'];
    if (type != 'message') {
      NotificationHelper.showNotification(message, flutterLocalNotificationsPlugin);
    }
    // Refresh pending offers on new ride request
    if (type == 'new_ride' || type == 'ride_request') {
      Get.find<RideController>().getPendingRideRequestList(1, isUpdate: true);
    }
  }

  @override
  void dispose() {
    _fcmSub.cancel();
    _pageCtrl.dispose();
    super.dispose();
  }

  void _setPage(int index) {
    setState(() {
      _pageCtrl.jumpToPage(index);
      _pageIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (_pageIndex != 0) {
          _setPage(0);
          return;
        }
        if (_canExit) {
          if (GetPlatform.isAndroid) {
            SystemNavigator.pop();
          } else if (GetPlatform.isIOS) {
            exit(0);
          }
          return;
        }
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('back_press_again_to_exit'.tr,
              style: const TextStyle(color: Colors.white)),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 2),
          margin: const EdgeInsets.all(Dimensions.paddingSizeSmall),
        ));
        _canExit = true;
        Timer(const Duration(seconds: 2), () => _canExit = false);
      },
      child: Scaffold(
        bottomNavigationBar: Container(
          height: 70 + MediaQuery.of(context).padding.bottom,
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            boxShadow: [BoxShadow(
              color: Colors.grey[Get.isDarkMode ? 800 : 200]!,
              spreadRadius: 1, blurRadius: 5,
            )],
          ),
          padding: const EdgeInsets.only(top: 14),
          child: Row(children: [
            BottomNavItemWidget(
              iconData: Images.home,
              label: 'home'.tr,
              isSelected: _pageIndex == 0,
              onTap: () => _setPage(0),
            ),
            BottomNavItemWidget(
              iconData: Images.request,
              label: 'request'.tr,
              isSelected: _pageIndex == 1,
              pageIndex: 1,
              onTap: () => _setPage(1),
            ),
            BottomNavItemWidget(
              iconData: Images.bag,
              label: 'history'.tr,
              isSelected: _pageIndex == 2,
              onTap: () => _setPage(2),
            ),
            BottomNavItemWidget(
              iconData: Images.userP,
              label: 'profile'.tr,
              isSelected: _pageIndex == 3,
              onTap: () => _setPage(3),
            ),
          ]),
        ),
        body: PageView.builder(
          controller: _pageCtrl,
          itemCount: _screens.length,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (_, i) => _screens[i],
        ),
      ),
    );
  }
}
