import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/profile/domain/models/level_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/leaderboard/domain/services/leader_board_service_interface.dart';

class LeaderBoardController extends GetxController implements GetxService {
  final LeaderBoardServiceInterface leaderBoardServiceInterface;
  LeaderBoardController({required this.leaderBoardServiceInterface});

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  LevelModel? levelModel;

  Future<void> getLevel() async {
    _isLoading = true;
    update();
    final response = await leaderBoardServiceInterface.getLevel();
    _isLoading = false;
    if (response.statusCode == 200 && response.body != null) {
      levelModel = LevelModel.fromJson(response.body);
    }
    update();
  }
}
