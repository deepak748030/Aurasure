import 'dart:io';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_asset_image_widget.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_card.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_drop_down_button.dart';
import 'package:sixam_mart_delivery/features/address/controllers/address_controller.dart';
import 'package:sixam_mart_delivery/features/auth/controllers/auth_controller.dart';
import 'package:sixam_mart_delivery/features/auth/widgets/pass_view_widget.dart';
import 'package:sixam_mart_delivery/features/splash/controllers/splash_controller.dart';
import 'package:sixam_mart_delivery/helper/custom_validator_helper.dart';
import 'package:sixam_mart_delivery/helper/route_helper.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_button_widget.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_snackbar_widget.dart';
import 'package:sixam_mart_delivery/common/widgets/custom_text_field_widget.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/images.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Registration form for ride-share drivers (riders).
/// Submits to the RideShare driver register endpoint. New accounts start as
/// 'pending' and must be approved by an admin before they can log in.
class RiderRegistrationScreen extends StatefulWidget {
  const RiderRegistrationScreen({super.key});

  @override
  State<RiderRegistrationScreen> createState() => _RiderRegistrationScreenState();
}

class _RiderRegistrationScreenState extends State<RiderRegistrationScreen> {
  final TextEditingController _fNameController = TextEditingController();
  final TextEditingController _lNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  final TextEditingController _identityNumberController = TextEditingController();

  final FocusNode _fNameNode = FocusNode();
  final FocusNode _lNameNode = FocusNode();
  final FocusNode _emailNode = FocusNode();
  final FocusNode _phoneNode = FocusNode();
  final FocusNode _passwordNode = FocusNode();
  final FocusNode _confirmPasswordNode = FocusNode();
  final FocusNode _identityNumberNode = FocusNode();

  String? _countryDialCode;

  @override
  void initState() {
    super.initState();
    _countryDialCode = CountryCode.fromCountryCode(Get.find<SplashController>().configModel!.country!).dialCode;
    Get.find<AuthController>().resetDmRegistrationData();
    Get.find<AddressController>().resetSelectedDeliveryZone();
    Get.find<AddressController>().getZoneList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('rider_registration'.tr,
            style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeLarge, color: Theme.of(context).textTheme.bodyLarge!.color)),
        centerTitle: true,
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        elevation: 2,
      ),
      body: GetBuilder<AuthController>(builder: (authController) {
        return GetBuilder<AddressController>(builder: (addressController) {
          return Column(children: [
            Expanded(child: SingleChildScrollView(
              padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                Text('basic_information'.tr, style: robotoBold),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                CustomCard(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                  child: Column(children: [
                    CustomTextFieldWidget(
                      labelText: 'first_name'.tr, hintText: 'ex_jhon'.tr, isRequired: true,
                      controller: _fNameController, capitalization: TextCapitalization.words,
                      inputType: TextInputType.name, focusNode: _fNameNode, nextFocus: _lNameNode,
                    ),
                    const SizedBox(height: Dimensions.paddingSizeExtraLarge),
                    CustomTextFieldWidget(
                      labelText: 'last_name'.tr, hintText: 'ex_doe'.tr,
                      controller: _lNameController, capitalization: TextCapitalization.words,
                      inputType: TextInputType.name, focusNode: _lNameNode, nextFocus: _emailNode,
                    ),
                    const SizedBox(height: Dimensions.paddingSizeExtraLarge),
                    CustomTextFieldWidget(
                      labelText: 'email'.tr, hintText: 'enter_email'.tr,
                      controller: _emailController, focusNode: _emailNode, nextFocus: _phoneNode,
                      inputType: TextInputType.emailAddress,
                    ),
                  ]),
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                Text('account_information'.tr, style: robotoBold),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                CustomCard(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                  child: Column(children: [
                    CustomTextFieldWidget(
                      labelText: 'phone'.tr, hintText: 'xxx-xxx-xxxxx'.tr, isRequired: true,
                      controller: _phoneController, focusNode: _phoneNode, nextFocus: _passwordNode,
                      inputType: TextInputType.phone, isPhone: true,
                      onCountryChanged: (CountryCode countryCode) => _countryDialCode = countryCode.dialCode,
                      countryDialCode: CountryCode.fromCountryCode(Get.find<SplashController>().configModel!.country!).code,
                    ),
                    const SizedBox(height: Dimensions.paddingSizeExtraLarge),
                    CustomTextFieldWidget(
                      labelText: 'password'.tr, hintText: 'eight_characters'.tr, isRequired: true,
                      controller: _passwordController, focusNode: _passwordNode, nextFocus: _confirmPasswordNode,
                      inputType: TextInputType.visiblePassword, isPassword: true,
                      onChanged: (value) {
                        if (value != null && value.isNotEmpty) {
                          if (!authController.showPassView) authController.showHidePass();
                          authController.validPassCheck(value);
                        } else if (authController.showPassView) {
                          authController.showHidePass();
                        }
                      },
                    ),
                    authController.showPassView ? const Align(alignment: Alignment.centerLeft, child: PassViewWidget()) : const SizedBox(),
                    const SizedBox(height: Dimensions.paddingSizeExtraLarge),
                    CustomTextFieldWidget(
                      labelText: 'confirm_password'.tr, hintText: 're_enter_your_password'.tr, isRequired: true,
                      controller: _confirmPasswordController, focusNode: _confirmPasswordNode,
                      inputAction: TextInputAction.done, inputType: TextInputType.visiblePassword, isPassword: true,
                    ),
                  ]),
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                Text('setup'.tr, style: robotoBold),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                CustomCard(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                  child: Column(children: [
                    addressController.zoneList != null ? CustomDropdownButton(
                      hintText: 'select_delivery_zone'.tr,
                      dropdownMenuItems: addressController.zoneList!.map((zone) => DropdownMenuItem<String>(
                        value: zone.id.toString(),
                        child: Text(zone.name ?? '', style: robotoRegular.copyWith(color: Theme.of(context).textTheme.bodyLarge?.color)),
                      )).toList(),
                      selectedValue: addressController.selectedDeliveryZoneId,
                      onChanged: (value) => addressController.setSelectedDeliveryZone(zoneId: value),
                    ) : const SizedBox(height: 50),
                    const SizedBox(height: Dimensions.paddingSizeExtraLarge),
                    CustomDropdownButton(
                      hintText: 'select_identity_type'.tr,
                      items: authController.identityTypeList,
                      selectedValue: authController.selectedIdentityType,
                      onChanged: (value) => authController.setSelectedIdentityType(value),
                    ),
                    const SizedBox(height: Dimensions.paddingSizeExtraLarge),
                    CustomTextFieldWidget(
                      hintText: 'Ex: xxx-xxxx-xxxxx',
                      labelText: authController.selectedIdentityType != null ? '${authController.selectedIdentityType?.tr} ${'number'.tr}' : 'identity_number'.tr,
                      controller: _identityNumberController, focusNode: _identityNumberNode, inputAction: TextInputAction.done,
                    ),
                  ]),
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                CustomCard(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('profile_picture'.tr, style: robotoBold.copyWith(color: Theme.of(context).textTheme.bodyLarge!.color)),
                    const SizedBox(height: Dimensions.paddingSizeLarge),
                    Align(alignment: Alignment.center, child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.all(2),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                          child: authController.pickedImage != null ? (GetPlatform.isWeb ? Image.network(
                            authController.pickedImage!.path, width: 120, height: 120, fit: BoxFit.cover,
                          ) : Image.file(File(authController.pickedImage!.path), width: 120, height: 120, fit: BoxFit.cover)) : SizedBox(
                            width: 120, height: 120,
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              CustomAssetImageWidget(image: Images.pictureIcon, height: 30, width: 30, color: Theme.of(context).disabledColor),
                              const SizedBox(height: Dimensions.paddingSizeSmall),
                              Text('click_to_add'.tr, style: robotoMedium.copyWith(color: Theme.of(context).hintColor, fontSize: Dimensions.fontSizeSmall), textAlign: TextAlign.center),
                            ]),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 0, right: 0, top: 0, left: 0,
                        child: InkWell(
                          onTap: () => authController.pickDmImageForRegistration(true, false),
                          child: DottedBorder(
                            options: RoundedRectDottedBorderOptions(
                              color: Theme.of(context).disabledColor, strokeWidth: 1, dashPattern: const [5, 5],
                              padding: const EdgeInsets.all(0), radius: const Radius.circular(Dimensions.radiusDefault),
                            ),
                            child: const SizedBox(width: 120, height: 120),
                          ),
                        ),
                      ),
                    ])),
                  ]),
                ),
              ]),
            )),

            Padding(
              padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
              child: CustomButtonWidget(
                buttonText: 'register'.tr,
                isLoading: authController.isLoading,
                onPressed: () => _submit(authController, addressController),
              ),
            ),
          ]);
        });
      }),
    );
  }

  void _submit(AuthController authController, AddressController addressController) async {
    final String fName = _fNameController.text.trim();
    final String phone = _phoneController.text.trim();
    final String password = _passwordController.text.trim();
    final String confirmPassword = _confirmPasswordController.text.trim();

    String numberWithCountryCode = (_countryDialCode ?? '') + phone;
    PhoneValid phoneValid = await CustomValidator.isPhoneValid(numberWithCountryCode);
    numberWithCountryCode = phoneValid.phone;

    if (fName.isEmpty) {
      showCustomSnackBar('enter_your_first_name'.tr);
    } else if (phone.isEmpty) {
      showCustomSnackBar('enter_phone_number'.tr);
    } else if (!phoneValid.isValid) {
      showCustomSnackBar('invalid_phone_number'.tr);
    } else if (password.isEmpty || password.length < 6) {
      showCustomSnackBar('password_should_be'.tr);
    } else if (password != confirmPassword) {
      showCustomSnackBar('password_does_not_match'.tr);
    } else {
      final Map<String, String> body = {
        'f_name': fName,
        'l_name': _lNameController.text.trim(),
        'phone': numberWithCountryCode,
        'email': _emailController.text.trim(),
        'password': password,
      };
      if (addressController.selectedDeliveryZoneId != null) {
        body['zone_id'] = addressController.selectedDeliveryZoneId!;
      }
      if (authController.selectedIdentityType != null) {
        body['identity_type'] = authController.selectedIdentityType!;
      }
      if (_identityNumberController.text.trim().isNotEmpty) {
        body['identity_number'] = _identityNumberController.text.trim();
      }
      bool ok = await authController.registerRider(body);
      if (!ok) {
        showCustomSnackBar('registration_failed'.tr);
      }
    }
  }
}
