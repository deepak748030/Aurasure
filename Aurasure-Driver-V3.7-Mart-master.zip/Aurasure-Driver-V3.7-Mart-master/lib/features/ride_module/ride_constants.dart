/// All RideShare driver API constants — self-contained inside ride_module.
/// Base URL is read from AppConstants.baseUrl at runtime.
class RideConstants {
  // ── Auth ──────────────────────────────────────────────────────────────
  static const String loginUri        = '/api/v1/ride-share/driver/auth/login';
  static const String registerUri     = '/api/v1/ride-share/driver/auth/register';
  static const String logoutUri       = '/api/v1/ride-share/driver/auth/logout';
  static const String fcmTokenUri     = '/api/v1/ride-share/driver/fcm-token';

  // ── Status ────────────────────────────────────────────────────────────
  static const String statusToggleUri = '/api/v1/ride-share/driver/status/toggle';
  static const String heartbeatUri    = '/api/v1/ride-share/driver/status/heartbeat';

  // ── Location ──────────────────────────────────────────────────────────
  static const String locationUri     = '/api/v1/ride-share/driver/location';

  // ── Ride lifecycle ────────────────────────────────────────────────────
  static const String offersUri       = '/api/v1/ride-share/driver/ride/offers';
  static const String acceptUri       = '/api/v1/ride-share/driver/ride/accept';
  static const String rejectUri       = '/api/v1/ride-share/driver/ride/reject';
  static const String startUri        = '/api/v1/ride-share/driver/ride/start';
  static const String completeUri     = '/api/v1/ride-share/driver/ride/complete';
  static const String rideListUri     = '/api/v1/ride-share/driver/ride/list';
  // PUT /api/v1/ride-share/driver/ride/status/{arriving|arrived}
  static const String rideStatusUri   = '/api/v1/ride-share/driver/ride/status';

  // ── Earnings ──────────────────────────────────────────────────────────
  static const String earningSummaryUri      = '/api/v1/ride-share/driver/earning/summary';
  static const String earningTransactionsUri = '/api/v1/ride-share/driver/earning/transactions';
  static const String earningReportUri       = '/api/v1/ride-share/driver/earning-report';
  static const String pointConvertUri        = '/api/v1/ride-share/driver/convert-loyalty-points';

  // ── Profile / level ───────────────────────────────────────────────────
  static const String profileUri      = '/api/v1/ride-share/driver/profile';
  static const String levelUri        = '/api/v1/ride-share/driver/level';
  static const String vehicleUri      = '/api/v1/ride-share/driver/vehicle';

  // ── Zone ──────────────────────────────────────────────────────────────
  // Same endpoint as AppConstants.zoneUri — kept here so ride-module code
  // has no dependency on AppConstants.
  static const String zoneIdUri       = '/api/v1/config/get-zone-id';

  // ── Documents ─────────────────────────────────────────────────────────
  static const String documentsUri    = '/api/v1/ride-share/driver/documents';

  // ── SharedPreferences key for driver token ────────────────────────────
  static const String tokenKey        = 'ride_share_driver_token';

  // ── Ride status strings (match backend enum in rides table) ──────────
  static const String statusRequested    = 'requested';
  static const String statusSearching    = 'searching';
  static const String statusAccepted     = 'accepted';
  static const String statusArriving     = 'arriving';   // driver en-route to pickup
  static const String statusArrived      = 'arrived';    // driver at pickup point
  static const String statusInProgress   = 'in_progress'; // ride ongoing / out for pickup
  static const String statusCompleted    = 'completed';
  static const String statusCancelled    = 'cancelled';
  static const String statusNoDriver     = 'no_driver_found';
  static const String statusPaymentFailed= 'payment_failed';

  // ── Aliases used by ride_helper.dart ─────────────────────────────────
  // The old code referenced AppConstants.ongoing / AppConstants.outForPickup.
  // Those map to the real backend statuses below.
  static const String ongoing      = statusInProgress;  // 'in_progress'
  static const String outForPickup = statusArriving;    // 'arriving'
}
