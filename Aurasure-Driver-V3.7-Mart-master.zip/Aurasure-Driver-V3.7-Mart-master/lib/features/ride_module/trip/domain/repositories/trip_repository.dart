import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sixam_mart_delivery/api/api_client.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_constants.dart';
import 'trip_repository_interface.dart';

class TripRepository implements TripRepositoryInterface {
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;
  TripRepository({required this.sharedPreferences, required this.apiClient});

  Map<String, String> get _headers => {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization':
            'Bearer ${sharedPreferences.getString(RideConstants.tokenKey) ?? ''}',
      };

  @override
  Future<Response> getTripList(int offset, {int limit = 20}) =>
      apiClient.getData(
        '${RideConstants.rideListUri}/completed?limit=$limit&offset=$offset',
        headers: _headers,
      );

  @override
  Future<Response> getEarningSummary() =>
      apiClient.getData(RideConstants.earningSummaryUri, headers: _headers);
}
