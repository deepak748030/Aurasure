import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sixam_mart_delivery/api/api_client.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_constants.dart';
import 'ride_order_repository_interface.dart';

class RideOrderRepository implements RideOrderRepositoryInterface {
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;

  RideOrderRepository({
    required this.apiClient,
    required this.sharedPreferences,
  });

  // ── Token helpers ──────────────────────────────────────────────────────
  @override
  String? getDriverToken() =>
      sharedPreferences.getString(RideConstants.tokenKey);

  @override
  Future<void> saveDriverToken(String token) =>
      sharedPreferences.setString(RideConstants.tokenKey, token);

  @override
  Future<void> clearDriverToken() =>
      sharedPreferences.remove(RideConstants.tokenKey);

  @override
  bool isDriverLoggedIn() =>
      (sharedPreferences.getString(RideConstants.tokenKey) ?? '').isNotEmpty;

  /// Returns headers with the driver Bearer token.
  Map<String, String> get _driverHeaders => {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer ${getDriverToken() ?? ''}',
      };

  // ── Auth ──────────────────────────────────────────────────────────────
  @override
  Future<Response> login(String phone, String password) =>
      apiClient.postData(
        RideConstants.loginUri,
        {'phone': phone, 'password': password},
      );

  @override
  Future<Response> logout() =>
      apiClient.postData(RideConstants.logoutUri, {}, headers: _driverHeaders);

  @override
  Future<Response> updateFcmToken(String token) =>
      apiClient.putData(
        RideConstants.fcmTokenUri,
        {'fcm_token': token},
        headers: _driverHeaders,
      );

  @override
  Future<Response> getProfile() =>
      apiClient.getData(RideConstants.profileUri, headers: _driverHeaders);

  // ── Status ────────────────────────────────────────────────────────────
  @override
  Future<Response> toggleOnlineStatus(bool online) =>
      apiClient.postData(
        RideConstants.statusToggleUri,
        {'online': online},
        headers: _driverHeaders,
      );

  @override
  Future<Response> sendHeartbeat() =>
      apiClient.postData(RideConstants.heartbeatUri, {}, headers: _driverHeaders);

  // ── Location ──────────────────────────────────────────────────────────
  @override
  Future<Response> updateLocation({
    required double latitude,
    required double longitude,
    double? heading,
    double? speedKmph,
  }) {
    final body = <String, dynamic>{
      'latitude': latitude,
      'longitude': longitude,
      if (heading != null) 'heading': heading,
      if (speedKmph != null) 'speed_kmph': speedKmph,
    };
    return apiClient.postData(
      RideConstants.locationUri,
      body,
      headers: _driverHeaders,
    );
  }

  // ── Ride offers ───────────────────────────────────────────────────────
  @override
  Future<Response> getRideOffers() =>
      apiClient.getData(RideConstants.offersUri, headers: _driverHeaders);

  @override
  Future<Response> acceptRide(int rideId) =>
      apiClient.postData(
        RideConstants.acceptUri,
        {'ride_id': rideId},
        headers: _driverHeaders,
      );

  @override
  Future<Response> rejectRide(int rideId) =>
      apiClient.postData(
        RideConstants.rejectUri,
        {'ride_id': rideId},
        headers: _driverHeaders,
      );

  // ── Ride status updates ───────────────────────────────────────────────
  @override
  Future<Response> updateRideStatus(int rideId, String newStatus) =>
      apiClient.putData(
        '${RideConstants.rideStatusUri}/$newStatus',
        {'ride_id': rideId},
        headers: _driverHeaders,
      );

  @override
  Future<Response> startRide(int rideId, String otp) =>
      apiClient.postData(
        RideConstants.startUri,
        {'ride_id': rideId, 'otp': otp},
        headers: _driverHeaders,
      );

  @override
  Future<Response> completeRide({
    required int rideId,
    required double actualDistanceKm,
    required double actualDurationMin,
    double waitingMinutes = 0,
    double tollAmount = 0,
  }) =>
      apiClient.postData(
        RideConstants.completeUri,
        {
          'ride_id': rideId,
          'actual_distance_km': actualDistanceKm,
          'actual_duration_min': actualDurationMin,
          'waiting_minutes': waitingMinutes,
          'toll_amount': tollAmount,
        },
        headers: _driverHeaders,
      );

  // ── Ride list ─────────────────────────────────────────────────────────
  @override
  Future<Response> getRideList(String type, {int limit = 20, int offset = 1}) =>
      apiClient.getData(
        '${RideConstants.rideListUri}/$type?limit=$limit&offset=$offset',
        headers: _driverHeaders,
      );

  // ── Earnings ──────────────────────────────────────────────────────────
  @override
  Future<Response> getEarningSummary() =>
      apiClient.getData(RideConstants.earningSummaryUri, headers: _driverHeaders);

  @override
  Future<Response> getEarningTransactions({int limit = 25, int offset = 1}) =>
      apiClient.getData(
        '${RideConstants.earningTransactionsUri}?limit=$limit&offset=$offset',
        headers: _driverHeaders,
      );

  // ── Documents ─────────────────────────────────────────────────────────
  @override
  Future<Response> getDocuments() =>
      apiClient.getData(RideConstants.documentsUri, headers: _driverHeaders);
}
