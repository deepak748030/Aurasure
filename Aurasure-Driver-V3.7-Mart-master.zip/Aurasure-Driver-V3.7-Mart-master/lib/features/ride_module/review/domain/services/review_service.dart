import 'package:get/get_connect/http/src/response/response.dart';
import '../repositories/review_repository_interface.dart';
import 'review_service_interface.dart';

class ReviewService implements ReviewServiceInterface {
  final ReviewRepositoryInterface reviewRepositoryInterface;
  ReviewService({required this.reviewRepositoryInterface});

  @override
  Future<Response> getDriverProfile() =>
      reviewRepositoryInterface.getDriverProfile();
}
