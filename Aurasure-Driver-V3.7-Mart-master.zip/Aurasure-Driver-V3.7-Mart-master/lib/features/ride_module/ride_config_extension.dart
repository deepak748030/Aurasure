import 'package:sixam_mart_delivery/common/models/config_model.dart';
import 'package:sixam_mart_delivery/features/splash/controllers/splash_controller.dart';

/// RideShare-specific fields parsed from the /api/v1/config response.
///
/// Kept separate from ConfigModel so the core model has zero ride knowledge.
/// Access via: Get.find<SplashController>().rideConfig
class RideConfigModel {
  List<String>? vehicleFuelTypes;
  List<String>? vehicleTransmissionTypes;
  int? safetyFeatureStatus;
  int? safetyFeatureMinimumTripDelayTime;
  String? safetyFeatureMinimumTripDelayTimeType;
  int? afterTripCompleteSafetyFeatureSetTime;
  String? safetyFeatureEmergencyGovtNumber;
  int? bidOnFare;
  int? otpConfirmationForTrip;
  int? riderLevelStatus;
  bool? riderCanReviewCustomer;
  List<RiderFaqs>? riderFaqs;
  double? completionRadius;
  bool? showRiderEarning;
  double? minAmountToPayRider;
  LoyalityPointData? riderLoyalityPointData;
  ReferralData? riderReferralData;

  RideConfigModel({
    this.vehicleFuelTypes,
    this.vehicleTransmissionTypes,
    this.safetyFeatureStatus,
    this.safetyFeatureMinimumTripDelayTime,
    this.safetyFeatureMinimumTripDelayTimeType,
    this.afterTripCompleteSafetyFeatureSetTime,
    this.safetyFeatureEmergencyGovtNumber,
    this.bidOnFare,
    this.otpConfirmationForTrip,
    this.riderLevelStatus,
    this.riderCanReviewCustomer,
    this.riderFaqs,
    this.completionRadius,
    this.showRiderEarning,
    this.minAmountToPayRider,
    this.riderLoyalityPointData,
    this.riderReferralData,
  });

  RideConfigModel.fromJson(Map<String, dynamic> json) {
    vehicleFuelTypes = json['vehicle_fuel_types'] != null
        ? json['vehicle_fuel_types'].cast<String>()
        : [];
    vehicleTransmissionTypes = json['vehicle_transmission_types'] != null
        ? json['vehicle_transmission_types'].cast<String>()
        : [];
    safetyFeatureStatus = int.tryParse(json['safety_feature_status'].toString());
    safetyFeatureMinimumTripDelayTime = json['ride_safety_delay_time'];
    safetyFeatureMinimumTripDelayTimeType = json['ride_safety_delay_time_format'];
    afterTripCompleteSafetyFeatureSetTime =
        int.tryParse(json['safety_feature_after_ride_complete_time'].toString());
    safetyFeatureEmergencyGovtNumber = json['emergency_govt_number'];
    bidOnFare = int.tryParse(json['bid_on_fare'].toString());
    otpConfirmationForTrip = int.tryParse(json['ride_otp_confirmation'].toString());
    riderLevelStatus = int.tryParse(json['rider_level_status'].toString());
    riderCanReviewCustomer = json['rider_can_review_customer'] == 1;
    if (json['rider_faqs'] != null) {
      riderFaqs = <RiderFaqs>[];
      json['rider_faqs'].forEach((v) {
        riderFaqs!.add(RiderFaqs.fromJson(v));
      });
    }
    if (json['rider_completion_radius'] != null) {
      try {
        completionRadius = json['rider_completion_radius'].toDouble();
      } catch (e) {
        completionRadius = double.parse(json['rider_completion_radius'].toString());
      }
    }
    showRiderEarning = json['show_rider_earning'];
    minAmountToPayRider = json['min_amount_to_pay_rider']?.toDouble();
    riderLoyalityPointData = json['rider_loyality_point_data'] != null
        ? LoyalityPointData.fromJson(json['rider_loyality_point_data'])
        : null;
    riderReferralData = json['rider_referral_data'] != null
        ? ReferralData.fromJson(json['rider_referral_data'])
        : null;
  }
}

/// Exposes ride-specific config on SplashController without the core model
/// needing any ride knowledge. Access via:
///   Get.find<SplashController>().rideConfig
extension RideConfigExtension on SplashController {
  RideConfigModel? get rideConfig => configRawData != null
      ? RideConfigModel.fromJson(configRawData!)
      : null;
}
