import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:sixam_mart_delivery/common/widgets/title_widget.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/controllers/trip_controller.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Today's ride stats: trips count, acceptance rate, completion rate.
/// Data from TripController (earning/summary endpoint).
class RiderStatsRow extends StatelessWidget {
  const RiderStatsRow({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TripController>(builder: (ctrl) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(
          Dimensions.paddingSizeDefault, 0,
          Dimensions.paddingSizeDefault, Dimensions.paddingSizeDefault,
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          TitleWidget(title: 'rides'.tr),
          const SizedBox(height: Dimensions.paddingSizeExtraSmall),

          IntrinsicHeight(
            child: Row(children: [
              _StatCard(
                title: 'todays_rides'.tr,
                value: ctrl.todayRides.toString(),
                color: const Color(0xffE5EAFF),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),
              _StatCard(
                title: 'this_week'.tr,
                value: ctrl.weekEarning > 0
                    ? ctrl.weekEarning.toStringAsFixed(0)
                    : '0',
                color: const Color(0xffE1FFD8),
                prefix: '₹',
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),
              _StatCard(
                title: 'this_month'.tr,
                value: ctrl.monthEarning > 0
                    ? ctrl.monthEarning.toStringAsFixed(0)
                    : '0',
                color: const Color(0xffFFF3E0),
                prefix: '₹',
              ),
            ]),
          ),

        ]),
      );
    });
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String? value;
  final Color color;
  final String prefix;
  const _StatCard({
    required this.title,
    required this.value,
    required this.color,
    this.prefix = '',
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.paddingSizeSmall,
          vertical: Dimensions.paddingSizeLarge,
        ),
        decoration: BoxDecoration(
          color: value != null ? color : Theme.of(context).shadowColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          value != null
              ? Text(
                  '$prefix$value',
                  style: robotoBold.copyWith(
                    fontSize: Dimensions.fontSizeExtraLarge,
                    color: Theme.of(context).textTheme.bodyLarge?.color,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                )
              : Shimmer(
                  duration: const Duration(seconds: 2),
                  enabled: true,
                  color: Colors.grey[500]!,
                  child: Container(
                    height: 20, width: 40,
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(5),
                    ),
                  ),
                ),
          const SizedBox(height: Dimensions.paddingSizeExtraSmall),
          Text(title,
              style: robotoRegular.copyWith(
                color: Theme.of(context).textTheme.bodyLarge?.color,
                fontSize: Dimensions.fontSizeSmall,
              ),
              textAlign: TextAlign.center),
        ]),
      ),
    );
  }
}
