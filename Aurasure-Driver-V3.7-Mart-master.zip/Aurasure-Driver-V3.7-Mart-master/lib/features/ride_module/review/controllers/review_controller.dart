import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/review/domain/services/review_service_interface.dart';

class ReviewController extends GetxController implements GetxService {
  final ReviewServiceInterface reviewServiceInterface;
  ReviewController({required this.reviewServiceInterface});

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  double avgRating = 0;
  int ratingCount = 0;

  Future<void> loadRating() async {
    _isLoading = true;
    update();
    final response = await reviewServiceInterface.getDriverProfile();
    _isLoading = false;
    if (response.statusCode == 200 && response.body != null) {
      avgRating = (response.body['avg_rating'] ?? 0).toDouble();
      ratingCount = response.body['rating_count'] ?? 0;
    }
    update();
  }
}
