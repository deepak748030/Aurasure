import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/splash/controllers/splash_controller.dart';
import 'package:sixam_mart_delivery/util/app_constants.dart';
import 'package:sixam_mart_delivery/util/enums.dart';

/// Runtime driver mode — replaces the compile-time AppConstants.appMode.
///
/// The admin controls two toggles in Business Settings:
///   - "Enable Delivery Man Registration" → toggle_dm_registration
///   - "Enable Rider Registration"        → toggle_rider_registration
///
/// This class derives the effective mode from those two flags at runtime:
///   - only delivery enabled  → delivery
///   - only ride enabled      → ride
///   - both enabled           → both (user picks at sign-up/login)
///   - neither enabled        → delivery (fallback)
class DriverMode {
  /// Returns the effective mode based on backend config.
  /// Falls back to the compile-time AppConstants.appMode if config not loaded.
  static DriverAppMode get current {
    try {
      final config = Get.find<SplashController>().configModel;
      if (config == null) return _fromCompileTime();
      final hasDm   = config.toggleDmRegistration   == true;
      final hasRide = config.toggleRiderRegistration == true;
      if (hasDm && hasRide) return DriverAppMode.both;
      if (hasRide)          return DriverAppMode.ride;
      if (hasDm)            return DriverAppMode.delivery;
      // Neither toggle is on — fall back to compile-time constant
      return _fromCompileTime();
    } catch (_) {
      return _fromCompileTime();
    }
  }

  static DriverAppMode _fromCompileTime() {
    return AppConstants.appMode == AppMode.ride
        ? DriverAppMode.ride
        : DriverAppMode.delivery;
  }

  static bool get isDeliveryEnabled {
    final m = current;
    return m == DriverAppMode.delivery || m == DriverAppMode.both;
  }

  static bool get isRideEnabled {
    final m = current;
    return m == DriverAppMode.ride || m == DriverAppMode.both;
  }

  static bool get isBothEnabled => current == DriverAppMode.both;
}

/// Runtime app mode — extends the compile-time AppMode enum.
enum DriverAppMode { delivery, ride, both }
