import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/trip_details_model.dart';

/// Active ride screen — shown after driver accepts a ride.
/// Displays the map, ride details, and action buttons for each status step.
class RideOrderScreen extends StatefulWidget {
  const RideOrderScreen({super.key});

  @override
  State<RideOrderScreen> createState() => _RideOrderScreenState();
}

class _RideOrderScreenState extends State<RideOrderScreen> {
  GoogleMapController? _mapCtrl;
  final TextEditingController _otpCtrl = TextEditingController();

  @override
  void dispose() {
    _otpCtrl.dispose();
    _mapCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RideController>(builder: (ctrl) {
      final ride = ctrl.tripDetail;
      final state = ctrl.rideState;

      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: Stack(
          children: [
            // ── Map ──────────────────────────────────────────────
            _buildMap(ride),

            // ── Top bar ───────────────────────────────────────────
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Row(
                  children: [
                    _CircleBtn(
                      icon: Icons.arrow_back,
                      onTap: () => Get.back(),
                    ),
                    const Spacer(),
                    _StatusChip(state: state),
                  ],
                ),
              ),
            ),

            // ── Bottom panel ──────────────────────────────────────
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: _BottomPanel(
                ride: ride,
                state: state,
                ctrl: ctrl,
                otpCtrl: _otpCtrl,
              ),
            ),
          ],
        ),
      );
    });
  }

  Widget _buildMap(RideDetails? ride) {
    final lat = ride?.pickupCoordinates?.coordinates != null
        ? ride!.pickupCoordinates!.coordinates![1]
        : 27.7172;
    final lng = ride?.pickupCoordinates?.coordinates != null
        ? ride!.pickupCoordinates!.coordinates![0]
        : 85.3240;

    return GoogleMap(
      initialCameraPosition: CameraPosition(
          target: LatLng(lat, lng), zoom: 15),
      onMapCreated: (c) {
        _mapCtrl = c;
        c.setMapStyle('[]'); // light map
      },
      myLocationEnabled: true,
      myLocationButtonEnabled: false,
      zoomControlsEnabled: false,
      mapToolbarEnabled: false,
      compassEnabled: false,
      padding: const EdgeInsets.only(bottom: 320),
    );
  }
}

// ── Status chip ────────────────────────────────────────────────────────────
class _StatusChip extends StatelessWidget {
  final DriverRideState state;
  const _StatusChip({required this.state});

  @override
  Widget build(BuildContext context) {
    final label = _label(state);
    final color = _color(state, context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 13)),
    );
  }

  String _label(DriverRideState s) {
    switch (s) {
      case DriverRideState.accepted:   return 'Heading to Pickup';
      case DriverRideState.arriving:   return 'Arriving';
      case DriverRideState.arrived:    return 'At Pickup';
      case DriverRideState.inProgress: return 'Ride in Progress';
      case DriverRideState.completed:  return 'Completed';
      default:                         return 'Active';
    }
  }

  Color _color(DriverRideState s, BuildContext context) {
    switch (s) {
      case DriverRideState.accepted:   return Theme.of(context).primaryColor;
      case DriverRideState.arriving:   return Colors.orange;
      case DriverRideState.arrived:    return Colors.purple;
      case DriverRideState.inProgress: return Theme.of(context).colorScheme.error;
      case DriverRideState.completed:  return Theme.of(context).primaryColor;
      default:                         return Theme.of(context).disabledColor;
    }
  }
}

// ── Bottom panel ───────────────────────────────────────────────────────────
class _BottomPanel extends StatelessWidget {
  final RideDetails? ride;
  final DriverRideState state;
  final RideController ctrl;
  final TextEditingController otpCtrl;

  const _BottomPanel({
    required this.ride,
    required this.state,
    required this.ctrl,
    required this.otpCtrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        boxShadow: [
          BoxShadow(
              color: Color(0x22000000),
              blurRadius: 20,
              offset: Offset(0, -4)),
        ],
      ),
      padding: EdgeInsets.fromLTRB(
          20, 16, 20, MediaQuery.of(context).padding.bottom + 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Center(
            child: Container(
              width: 36, height: 4,
              margin: const EdgeInsets.only(bottom: 14),
              decoration: BoxDecoration(
                  color: const Color(0xFFDDDDDD),
                  borderRadius: BorderRadius.circular(2)),
            ),
          ),

          // Customer info
          if (ride != null) _CustomerRow(ride: ride!),
          const SizedBox(height: 12),

          // Route
          if (ride != null) _RouteRow(ride: ride!),
          const SizedBox(height: 12),

          // Open in Google Maps — destination depends on ride state:
          //   before in_progress → navigate to pickup
          //   in_progress        → navigate to drop-off
          if (ride != null) _OpenMapsButton(ride: ride!, state: state),
          const SizedBox(height: 12),

          // Action button based on state
          _ActionButton(
            state: state,
            ctrl: ctrl,
            otpCtrl: otpCtrl,
            rideId: int.tryParse(ride?.id ?? '') ?? 0,
          ),
        ],
      ),
    );
  }
}

// ── Customer row ───────────────────────────────────────────────────────────
class _CustomerRow extends StatelessWidget {
  final RideDetails ride;
  const _CustomerRow({required this.ride});

  @override
  Widget build(BuildContext context) {
    final name =
        '${ride.customer?.firstName ?? ''} ${ride.customer?.lastName ?? ''}'
            .trim();
    final phone = ride.customer?.phone ?? '';
    return Row(
      children: [
        CircleAvatar(
          radius: 22,
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          backgroundImage: (ride.customer?.profileImage ?? '').isNotEmpty
              ? NetworkImage(ride.customer!.profileImage!)
              : null,
          child: (ride.customer?.profileImage ?? '').isEmpty
              ? Icon(Icons.person, size: 22, color: Theme.of(context).disabledColor)
              : null,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name.isNotEmpty ? name : 'Customer',
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: Theme.of(context).textTheme.bodyLarge?.color)),
              if (phone.isNotEmpty)
                Text(phone,
                    style: TextStyle(
                        fontSize: 12, color: Theme.of(context).disabledColor)),
            ],
          ),
        ),
        // Call button
        GestureDetector(
          onTap: () {},
          child: Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                shape: BoxShape.circle,
                border: Border.all(color: Theme.of(context).dividerTheme.color ?? Colors.grey.shade300)),
            child: Icon(Icons.phone_outlined,
                size: 18, color: Theme.of(context).textTheme.bodyMedium?.color),
          ),
        ),
      ],
    );
  }
}

// ── Route row ──────────────────────────────────────────────────────────────
class _RouteRow extends StatelessWidget {
  final RideDetails ride;
  const _RouteRow({required this.ride});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 10, height: 10,
              decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor, shape: BoxShape.circle),
            ),
            Container(width: 1.5, height: 24, color: Theme.of(context).dividerTheme.color ?? Colors.grey.shade300),
            Container(
              width: 10, height: 10,
              decoration: BoxDecoration(
                border: Border.all(color: Theme.of(context).primaryColor, width: 2),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ],
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(ride.pickupAddress ?? 'Pickup',
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: Theme.of(context).textTheme.bodyLarge?.color),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              const SizedBox(height: 14),
              Text(ride.destinationAddress ?? 'Destination',
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: Theme.of(context).textTheme.bodyLarge?.color),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Text(
          '₹${ride.totalFare ?? ride.estimatedFare ?? '0'}',
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: Theme.of(context).textTheme.bodyLarge?.color),
        ),
      ],
    );
  }
}

// ── Action button ──────────────────────────────────────────────────────────
class _ActionButton extends StatelessWidget {
  final DriverRideState state;
  final RideController ctrl;
  final TextEditingController otpCtrl;
  final int rideId;

  const _ActionButton({
    required this.state,
    required this.ctrl,
    required this.otpCtrl,
    required this.rideId,
  });

  @override
  Widget build(BuildContext context) {
    switch (state) {
      case DriverRideState.accepted:
        return _PrimaryBtn(
          label: 'I\'m Arriving',
          onTap: () => ctrl.markArriving(),
          isLoading: ctrl.isLoading,
        );

      case DriverRideState.arriving:
        return _PrimaryBtn(
          label: 'I\'ve Arrived',
          onTap: () => ctrl.markArrived(),
          isLoading: ctrl.isLoading,
        );

      case DriverRideState.arrived:
        return Column(
          children: [
            // OTP input
            Container(
              height: 52,
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Theme.of(context).dividerTheme.color ?? Colors.grey.shade300),
              ),
              child: TextField(
                controller: otpCtrl,
                keyboardType: TextInputType.number,
                maxLength: 4,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 12),
                decoration: InputDecoration(
                  hintText: '• • • •',
                  hintStyle: TextStyle(
                      fontSize: 18, color: Theme.of(context).hintColor, letterSpacing: 8),
                  border: InputBorder.none,
                  counterText: '',
                  contentPadding: EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
            const SizedBox(height: 10),
            _PrimaryBtn(
              label: 'Start Ride',
              onTap: () async {
                if (otpCtrl.text.length == 4) {
                  await ctrl.startRideWithOtp(otpCtrl.text);
                  otpCtrl.clear();
                }
              },
              isLoading: ctrl.isLoading,
            ),
          ],
        );

      case DriverRideState.inProgress:
        return _PrimaryBtn(
          label: 'Complete Ride',
          onTap: () => _showCompleteDialog(context),
          isLoading: ctrl.isLoading,
          color: Theme.of(context).primaryColor,
        );

      case DriverRideState.completed:
        return ElevatedButton(
          onPressed: () {
            ctrl.resetAfterCompletion();
            Get.back();
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Theme.of(context).primaryColor,
            foregroundColor: Colors.white,
            minimumSize: const Size(double.infinity, 52),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
          child: const Text('Done',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        );

      default:
        return const SizedBox.shrink();
    }
  }

  void _showCompleteDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36, height: 4,
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                  color: const Color(0xFFDDDDDD),
                  borderRadius: BorderRadius.circular(2)),
            ),
            const Text('Complete Ride',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Color(0xFF111111))),
            const SizedBox(height: 8),
            const Text('Confirm you have reached the destination',
                style: TextStyle(fontSize: 14, color: Color(0xFF888888)),
                textAlign: TextAlign.center),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Get.back(),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: const BorderSide(color: Color(0xFFDDDDDD)),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Cancel',
                        style: TextStyle(color: Color(0xFF555555))),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () async {
                      Get.back();
                      await ctrl.completeRide(
                        actualDistanceKm:
                            ctrl.tripDetail?.estimatedDistance ?? 1,
                        actualDurationMin: double.tryParse(
                                ctrl.tripDetail?.estimatedTime ?? '10') ??
                            10,
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).primaryColor,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Complete',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Open in Google Maps button ─────────────────────────────────────────────
/// Before the ride starts (accepted / arriving / arrived) → navigate to pickup.
/// Once the ride is in progress → navigate to drop-off.
class _OpenMapsButton extends StatelessWidget {
  final RideDetails ride;
  final DriverRideState state;
  const _OpenMapsButton({required this.ride, required this.state});

  @override
  Widget build(BuildContext context) {
    final bool toDropOff = state == DriverRideState.inProgress;

    final double? lat = toDropOff
        ? (ride.destinationCoordinates?.coordinates?[1])
        : (ride.pickupCoordinates?.coordinates?[1]);
    final double? lng = toDropOff
        ? (ride.destinationCoordinates?.coordinates?[0])
        : (ride.pickupCoordinates?.coordinates?[0]);

    final String label = toDropOff
        ? 'Navigate to Drop-off'
        : 'Navigate to Pickup';

    final String address = toDropOff
        ? (ride.destinationAddress ?? '')
        : (ride.pickupAddress ?? '');

    // Nothing to navigate to
    if (lat == null || lng == null || lat == 0 || lng == 0) {
      return const SizedBox.shrink();
    }

    return SizedBox(
      width: double.infinity,
      height: 48,
      child: OutlinedButton.icon(
        onPressed: () => _openGoogleMaps(lat, lng, address),
        icon: const Icon(Icons.directions, size: 18),
        label: Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFF1A73E8),
          side: const BorderSide(color: Color(0xFF1A73E8), width: 1.5),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  Future<void> _openGoogleMaps(double lat, double lng, String address) async {
    // Try Google Maps app first (geo: URI), fall back to browser URL.
    // The `q=` param shows a pin with the address label.
    final encodedAddress = Uri.encodeComponent(address);
    final appUri = Uri.parse('google.navigation:q=$lat,$lng&mode=d');
    final webUri = Uri.parse(
        'https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&destination_place_id=$encodedAddress&travelmode=driving');

    if (await canLaunchUrl(appUri)) {
      await launchUrl(appUri);
    } else {
      await launchUrl(webUri, mode: LaunchMode.externalApplication);
    }
  }
}

class _PrimaryBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool isLoading;
  final Color? color;

  const _PrimaryBtn({
    required this.label,
    required this.onTap,
    this.isLoading = false,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: isLoading ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color ?? Theme.of(context).primaryColor,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
        ),
        child: isLoading
            ? const SizedBox(
                width: 22, height: 22,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white))
            : Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 16)),
      ),
    );
  }
}

// ── Circle button ──────────────────────────────────────────────────────────
class _CircleBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _CircleBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.12),
                blurRadius: 8,
                offset: const Offset(0, 2)),
          ],
        ),
        child: Icon(icon, size: 20, color: Theme.of(context).textTheme.bodyMedium?.color),
      ),
    );
  }
}
