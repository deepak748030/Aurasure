import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/pending_ride_request_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/ride_json_adapter.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/trip_details_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/services/ride_order_service_interface.dart';

/// Driver ride state machine.
/// Mirrors the backend Ride.status values:
///   OPEN:     requested | searching | accepted | arriving | arrived | in_progress
///   TERMINAL: completed | cancelled | no_driver_found | payment_failed
enum DriverRideState {
  initial,
  hasOffer,       // pending broadcast received
  accepted,       // driver accepted, heading to pickup
  arriving,       // driver marked as arriving
  arrived,        // driver at pickup, waiting for OTP
  inProgress,     // ride started (OTP matched)
  completed,
}

class RideController extends GetxController implements GetxService {
  final RideOrderServiceInterface rideOrderServiceInterface;
  RideController({required this.rideOrderServiceInterface});

  // ── State ──────────────────────────────────────────────────────────────
  DriverRideState _rideState = DriverRideState.initial;
  DriverRideState get rideState => _rideState;

  bool _isOnline = false;
  bool get isOnline => _isOnline;

  /// Sync online state from the backend profile response.
  /// Called on app startup so the toggle reflects the real server state.
  void setOnlineFromProfile(bool isOnline) {
    _isOnline = isOnline;
    if (_isOnline) {
      startOfferPolling();
      startHeartbeat();
    }
    update();
  }

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  // ── Data ───────────────────────────────────────────────────────────────
  String? _rideId;
  String? get rideId => _rideId;

  RideDetails? tripDetail;
  List<RideDetails>? _ongoingRide;
  List<RideDetails>? _lastRideDetails;
  List<RideDetails>? get ongoingRide => _ongoingRide;
  List<RideDetails>? get lastRideDetails => _lastRideDetails;

  PendingRideRequestModel? _pendingRideRequestModel;
  PendingRideRequestModel? get pendingRideRequestModel => _pendingRideRequestModel;

  // Offer polling timer
  Timer? _offerTimer;

  // ── Auth ───────────────────────────────────────────────────────────────
  bool get isDriverLoggedIn => rideOrderServiceInterface.isDriverLoggedIn();

  Future<bool> login(String phone, String password) async {
    _isLoading = true;
    update();
    final response = await rideOrderServiceInterface.login(phone, password);
    _isLoading = false;
    if (response.statusCode == 200 && response.body != null) {
      final token = response.body['token']?.toString() ?? '';
      if (token.isNotEmpty) {
        await rideOrderServiceInterface.saveDriverToken(token);
        update();
        return true;
      }
    }
    update();
    return false;
  }

  Future<void> logout() async {
    await rideOrderServiceInterface.logout();
    await rideOrderServiceInterface.clearDriverToken();
    _isOnline = false;
    _rideState = DriverRideState.initial;
    tripDetail = null;
    _rideId = null;
    stopOfferPolling();
    stopHeartbeat();
    update();
  }

  // ── Online / offline toggle ────────────────────────────────────────────
  Future<void> toggleOnline(bool online) async {
    // Optimistic update — show the new state immediately
    _isOnline = online;
    _isLoading = true;
    update();

    try {
      final response = await rideOrderServiceInterface.toggleOnlineStatus(online);

      if (response.statusCode == 200) {
        // Confirmed by server
        if (online) {
          startOfferPolling();
          startHeartbeat();
          _sendInitialLocation();
        } else {
          stopOfferPolling();
          stopHeartbeat();
        }
      } else {
        // Server rejected — revert
        _isOnline = !online;
        if (kDebugMode) {
          print('toggleOnline failed: ${response.statusCode} ${response.statusText} ${response.body}');
        }
      }
    } catch (e) {
      // Network error — revert
      _isOnline = !online;
      if (kDebugMode) {
        print('toggleOnline exception: $e');
      }
    }

    _isLoading = false;
    update();
  }

  // ── Heartbeat timer ────────────────────────────────────────────────────
  Timer? _heartbeatTimer;

  void startHeartbeat() {
    _heartbeatTimer?.cancel();
    // Send heartbeat every 60s to stay within the 120s TTL window.
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 60), (_) {
      rideOrderServiceInterface.sendHeartbeat();
    });
  }

  void stopHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
  }

  /// Called immediately when going online.
  /// Does NOT send a dummy (0,0) location — real GPS is sent by
  /// RiderOnlineToggle._toggleAndSendLocation() right after this.
  Future<void> _sendInitialLocation() async {
    // No-op: real GPS coordinates are sent by the toggle widget.
    // Sending (0,0) would place the driver 1200+ km away from any real pickup.
  }

  // ── Location ──────────────────────────────────────────────────────────
  Future<void> updateLocation(double lat, double lng, {double? heading}) async {
    await rideOrderServiceInterface.updateLocation(
      latitude: lat,
      longitude: lng,
      heading: heading,
    );
    // Also send heartbeat
    await rideOrderServiceInterface.sendHeartbeat();
  }

  // ── Offer polling ──────────────────────────────────────────────────────
  void startOfferPolling() {
    _offerTimer?.cancel();
    _offerTimer = Timer.periodic(const Duration(seconds: 8), (_) {
      if (_rideState == DriverRideState.initial) {
        getPendingRideRequestList(1);
      }
    });
  }

  void stopOfferPolling() {
    _offerTimer?.cancel();
    _offerTimer = null;
  }

  Future<Response?> getPendingRideRequestList(int offset,
      {int limit = 10, bool isUpdate = false}) async {
    final response = await rideOrderServiceInterface.getRideOffers();
    if (response.statusCode == 200 && response.body != null) {
      final list = response.body is List
          ? response.body as List
          : (response.body['data'] as List? ?? []);
      if (list.isNotEmpty) {
        // Each item is a RideBroadcast with a nested 'ride' object
        final rides = <RideDetails>[];
        for (final item in list) {
          try {
            final rideJson = (item['ride'] ?? item) as Map<String, dynamic>;
            rides.add(RideJsonAdapter.fromRideJson(rideJson));
          } catch (_) {}
        }
        _pendingRideRequestModel = PendingRideRequestModel(
          data: rides,
          totalSize: rides.length,
        );
        if (_rideState == DriverRideState.initial) {
          _rideState = DriverRideState.hasOffer;
        }
      } else {
        _pendingRideRequestModel = PendingRideRequestModel(data: []);
        if (_rideState == DriverRideState.hasOffer) {
          _rideState = DriverRideState.initial;
        }
      }
      if (isUpdate) update();
    }
    return response;
  }

  // ── Accept / reject ────────────────────────────────────────────────────
  Future<bool> acceptOffer(int rideId) async {
    _isLoading = true;
    update();
    final response = await rideOrderServiceInterface.acceptRide(rideId);
    _isLoading = false;
    if (response.statusCode == 200 && response.body != null) {
      try {
        tripDetail = RideJsonAdapter.fromRideJson(
            response.body as Map<String, dynamic>);
      } catch (_) {}
      _rideId = tripDetail?.id;
      _rideState = DriverRideState.accepted;
      stopOfferPolling();
      update();
      return true;
    }
    update();
    return false;
  }

  Future<void> rejectOffer(int rideId) async {
    await rideOrderServiceInterface.rejectRide(rideId);
    _pendingRideRequestModel?.data?.removeWhere((r) => r.id == rideId.toString());
    update();
  }

  // ── Status updates ─────────────────────────────────────────────────────
  Future<bool> markArriving() async {
    if (_rideId == null) return false;
    final response = await rideOrderServiceInterface.updateRideStatus(
        int.parse(_rideId!), 'arriving');
    if (response.statusCode == 200) {
      _rideState = DriverRideState.arriving;
      update();
      return true;
    }
    return false;
  }

  Future<bool> markArrived() async {
    if (_rideId == null) return false;
    final response = await rideOrderServiceInterface.updateRideStatus(
        int.parse(_rideId!), 'arrived');
    if (response.statusCode == 200) {
      _rideState = DriverRideState.arrived;
      update();
      return true;
    }
    return false;
  }

  Future<bool> startRideWithOtp(String otp) async {
    if (_rideId == null) return false;
    _isLoading = true;
    update();
    final response = await rideOrderServiceInterface.startRide(
        int.parse(_rideId!), otp);
    _isLoading = false;
    if (response.statusCode == 200) {
      _rideState = DriverRideState.inProgress;
      update();
      return true;
    }
    update();
    return false;
  }

  Future<bool> completeRide({
    required double actualDistanceKm,
    required double actualDurationMin,
    double waitingMinutes = 0,
    double tollAmount = 0,
  }) async {
    if (_rideId == null) return false;
    _isLoading = true;
    update();
    final response = await rideOrderServiceInterface.completeRide(
      rideId: int.parse(_rideId!),
      actualDistanceKm: actualDistanceKm,
      actualDurationMin: actualDurationMin,
      waitingMinutes: waitingMinutes,
      tollAmount: tollAmount,
    );
    _isLoading = false;
    if (response.statusCode == 200 && response.body != null) {
      try {
        tripDetail = RideJsonAdapter.fromRideJson(
            response.body as Map<String, dynamic>);
      } catch (_) {}
      _rideState = DriverRideState.completed;
      update();
      return true;
    }
    update();
    return false;
  }

  void resetAfterCompletion() {
    _rideState = DriverRideState.initial;
    tripDetail = null;
    _rideId = null;
    if (_isOnline) startOfferPolling();
    update();
  }

  Future<Response> ongoingTripList() async {
    final response = await rideOrderServiceInterface.getRideList('active');
    if (response.statusCode == 200 && response.body != null) {
      final list = response.body['rides'] as List? ?? [];
      _ongoingRide = list.map((e) {
        try {
          return RideJsonAdapter.fromRideJson(e as Map<String, dynamic>);
        } catch (_) {
          return RideDetails();
        }
      }).toList();

      // ── Auto-restore active ride state on app reopen ──────────────────
      // If there is exactly one active ride and _rideId is not yet set
      // (i.e. the driver reopened the app mid-ride), restore _rideId and
      // _rideState so all action buttons work without requiring the driver
      // to tap through to the ride screen first.
      if (_ongoingRide != null &&
          _ongoingRide!.isNotEmpty &&
          _rideId == null) {
        final active = _ongoingRide!.first;
        if (active.id != null && active.id!.isNotEmpty) {
          tripDetail = active;
          _rideId = active.id;
          _restoreStateFromStatus(active.currentStatus);
          stopOfferPolling();
        }
      }

      update();
    }
    return response;
  }

  Future<void> getLastRideDetail() async {
    final response = await rideOrderServiceInterface.getRideList('completed',
        limit: 1, offset: 1);
    if (response.statusCode == 200 && response.body != null) {
      final list = response.body['rides'] as List? ?? [];
      _lastRideDetails = list.map((e) {
        try {
          return RideJsonAdapter.fromRideJson(e as Map<String, dynamic>);
        } catch (_) {
          return RideDetails();
        }
      }).toList();
      update();
    }
  }

  Future<RideDetails?> getRideDetails(String rideId,
      {bool reload = false}) async {
    final response = await rideOrderServiceInterface.getRideList('active');
    if (response.statusCode == 200 && response.body != null) {
      final list = response.body['rides'] as List? ?? [];
      for (final item in list) {
        try {
          final rd = RideJsonAdapter.fromRideJson(item as Map<String, dynamic>);
          if (rd.id == rideId) {
            tripDetail = rd;
            // ── Restore _rideId and _rideState from the backend status ──
            // Without this, all action buttons (markArriving, startRide, etc.)
            // guard with `if (_rideId == null) return false` and silently fail
            // when the driver reopens the app mid-ride.
            _rideId = rd.id;
            _restoreStateFromStatus(rd.currentStatus);
            stopOfferPolling(); // active ride — no need to poll for offers
            update();
            return rd;
          }
        } catch (_) {}
      }
    }
    return null;
  }

  /// Maps backend Ride.status → DriverRideState.
  /// Called when resuming an active ride after app reopen.
  void _restoreStateFromStatus(String? status) {
    switch (status) {
      case 'accepted':
        _rideState = DriverRideState.accepted;
        break;
      case 'arriving':
        _rideState = DriverRideState.arriving;
        break;
      case 'arrived':
        _rideState = DriverRideState.arrived;
        break;
      case 'in_progress':
      case 'ongoing': // legacy alias
        _rideState = DriverRideState.inProgress;
        break;
      case 'completed':
        _rideState = DriverRideState.completed;
        break;
      default:
        // Leave state as-is if status is unrecognised
        break;
    }
  }

  Future<Response> getRideDetailsFromMapIcon(String rideId) async {
    return await rideOrderServiceInterface.getRideList('active');
  }

  Future<Response> getRideDetailBeforeAccept(String tripId) async {
    return await rideOrderServiceInterface.getRideOffers();
  }

  Future<Response> remainingDistance(String tripId,
      {bool mapBound = false}) async {
    return Response(statusCode: 200, body: {});
  }

  Future<Response> getFinalFare(String tripId) async {
    return Response(statusCode: 200, body: {});
  }

  void updateRoute(bool showHideIcon, {bool notify = false}) {}

  void setRideId(String id) {
    _rideId = id;
    update();
  }

  void setRideGetMessage(bool value) => update();

  @override
  void onClose() {
    stopOfferPolling();
    stopHeartbeat();
    super.onClose();
  }
}
