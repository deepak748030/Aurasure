import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/add_vehicle/controllers/add_vehicle_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/add_vehicle/domain/repositories/add_vehicle_repository.dart';
import 'package:sixam_mart_delivery/features/ride_module/add_vehicle/domain/repositories/add_vehicle_repository_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/add_vehicle/domain/services/add_vehicle_service.dart';
import 'package:sixam_mart_delivery/features/ride_module/add_vehicle/domain/services/add_vehicle_service_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/leaderboard/controllers/leader_board_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/leaderboard/domain/repositories/leader_board_repository.dart';
import 'package:sixam_mart_delivery/features/ride_module/leaderboard/domain/repositories/leader_board_repository_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/leaderboard/domain/services/leader_board_service.dart';
import 'package:sixam_mart_delivery/features/ride_module/leaderboard/domain/services/leader_board_service_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/map/controllers/otp_time_count_Controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/map/controllers/ride_map_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/review/controllers/review_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/review/domain/repositories/review_repository.dart';
import 'package:sixam_mart_delivery/features/ride_module/review/domain/repositories/review_repository_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/review/domain/services/review_service.dart';
import 'package:sixam_mart_delivery/features/ride_module/review/domain/services/review_service_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/repositories/ride_order_repository.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/repositories/ride_order_repository_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/services/ride_order_service.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/services/ride_order_service_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/safety/controllers/safety_alert_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/safety/domain/repositories/safety_alert_repository.dart';
import 'package:sixam_mart_delivery/features/ride_module/safety/domain/repositories/safety_alert_repository_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/safety/domain/services/safety_alert_service.dart';
import 'package:sixam_mart_delivery/features/ride_module/safety/domain/services/safety_alert_service_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/controllers/trip_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/domain/repositories/trip_repository.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/domain/repositories/trip_repository_interface.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/domain/services/trip_service.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/domain/services/trip_service_interface.dart';

/// RideShareModule
///
/// This is the ONLY place in the core app that imports ride_module code.
/// Call [RideShareModule.registerDependencies] from get_di.dart instead of
/// scattering ride imports throughout the DI file.
///
/// Mirrors the pattern of RideShareServiceProvider on the backend.
class RideShareModule {
  RideShareModule._();

  /// Register all ride-module repositories, services, and controllers.
  /// Called once from get_di.dart init().
  static void registerDependencies() {
    // ── Repositories ────────────────────────────────────────────────────────
    AddVehicleRepositoryInterface addVehicleRepo =
        AddVehicleRepository(apiClient: Get.find(), sharedPreferences: Get.find());
    Get.lazyPut(() => addVehicleRepo);

    RideOrderRepositoryInterface rideOrderRepo =
        RideOrderRepository(apiClient: Get.find(), sharedPreferences: Get.find());
    Get.lazyPut(() => rideOrderRepo);

    TripRepositoryInterface tripRepo =
        TripRepository(apiClient: Get.find(), sharedPreferences: Get.find());
    Get.lazyPut(() => tripRepo);

    SafetyAlertRepositoryInterface safetyRepo =
        SafetyAlertRepository(apiClient: Get.find(), sharedPreferences: Get.find());
    Get.lazyPut(() => safetyRepo);

    ReviewRepositoryInterface reviewRepo =
        ReviewRepository(apiClient: Get.find(), sharedPreferences: Get.find());
    Get.lazyPut(() => reviewRepo);

    LeaderBoardRepositoryInterface leaderRepo =
        LeaderBoardRepository(apiClient: Get.find(), sharedPreferences: Get.find());
    Get.lazyPut(() => leaderRepo);

    // ── Services ─────────────────────────────────────────────────────────────
    AddVehicleServiceInterface addVehicleService =
        AddVehicleService(addVehicleRepositoryInterface: Get.find());
    Get.lazyPut(() => addVehicleService);

    RideOrderServiceInterface rideOrderService =
        RideOrderService(rideOrderRepositoryInterface: Get.find());
    Get.lazyPut(() => rideOrderService);

    TripServiceInterface tripService =
        TripService(tripRepositoryInterface: Get.find());
    Get.lazyPut(() => tripService);

    SafetyAlertServiceInterface safetyService =
        SafetyAlertService(safetyAlertRepositoryInterface: Get.find());
    Get.lazyPut(() => safetyService);

    ReviewServiceInterface reviewService =
        ReviewService(reviewRepositoryInterface: Get.find());
    Get.lazyPut(() => reviewService);

    LeaderBoardServiceInterface leaderService =
        LeaderBoardService(leaderBoardRepositoryInterface: Get.find());
    Get.lazyPut(() => leaderService);

    // ── Controllers ───────────────────────────────────────────────────────────
    Get.lazyPut(() => RiderMapController());
    Get.lazyPut(() => AddVehicleController(addVehicleServiceInterface: Get.find()));
    Get.lazyPut(() => RideController(rideOrderServiceInterface: Get.find()));
    Get.lazyPut(() => TripController(tripServiceInterface: Get.find()));
    Get.lazyPut(() => SafetyAlertController(safetyAlertServiceInterface: Get.find()));
    Get.lazyPut(() => OtpTimeCountController());
    Get.lazyPut(() => ReviewController(reviewServiceInterface: Get.find()));
    Get.lazyPut(() => LeaderBoardController(leaderBoardServiceInterface: Get.find()));
  }
}
