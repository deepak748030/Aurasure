import 'package:get/get.dart';
enum RideState{initial, pending, accepted, outForPickup ,ongoing, acceptingRider, completed, fareCalculating}

class RiderMapController extends GetxController implements GetxService {
  RideState currentRideState = RideState.initial;
  void setRideCurrentState(RideState newState, {bool notify = true}){}
  void setMarkersInitialPosition({bool bindLocation = false}){}
  void getPickupToDestinationPolyline({bool updateLiveLocation = false}) async {}

  /// Called by PusherHelper when a driver.location.updated event arrives.
  /// Updates the driver marker on the in-trip map.
  void updateDriverLocationFromPusher({
    required double lat,
    required double lng,
    double? heading,
  }) {
    // Map marker update — implemented when map screen is built out.
    // Stub kept so PusherHelper compiles without errors.
  }
}