import 'package:get/get_connect/http/src/response/response.dart';

abstract class SafetyAlertRepositoryInterface {
  /// POST /api/v1/ride-share/user/sos — trigger SOS for the current ride.
  Future<Response> triggerSos({required String rideId, required String message});
}
