import 'package:fl_chart/fl_chart.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/ride_json_adapter.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/domain/models/trip_details_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/domain/models/trip_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/domain/models/trip_overview_model.dart';
import '../domain/services/trip_service_interface.dart';

class TripController extends GetxController implements GetxService {
  final TripServiceInterface tripServiceInterface;
  TripController({required this.tripServiceInterface});

  TripModel? tripModel;
  List<FlSpot> earningChartList = [];
  double maxValue = 0;
  TripOverView? tripOverView;

  // Earning summary from backend
  double todayEarning = 0;
  double weekEarning = 0;
  double monthEarning = 0;
  int todayRides = 0;
  double walletBalance = 0;
  bool summaryLoaded = false;  // true once earning/summary has responded

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  final List<String> selectedOverviewType = ['today', 'this_week', 'last_week'];
  String _selectedOverview = 'today';
  String get selectedOverview => _selectedOverview;

  Future<Response> getTripList(int offset) async {
    _isLoading = true;
    update();
    final response = await tripServiceInterface.getTripList(offset);
    _isLoading = false;
    if (response.statusCode == 200 && response.body != null) {
      final rides = response.body['rides'] as List? ?? [];
      tripModel = TripModel(
        totalSize: response.body['total_size'],
        tripList: rides
            .map((e) {
              try {
                return RideJsonAdapter.fromRideJson(e as Map<String, dynamic>);
              } catch (_) {
                return RideDetails();
              }
            })
            .toList(),
      );
    }
    update();
    return response;
  }

  Future<void> loadEarningSummary() async {
    _isLoading = true;
    update();
    final response = await tripServiceInterface.getEarningSummary();
    _isLoading = false;
    if (response.statusCode == 200 && response.body != null) {
      final body = response.body;
      todayRides    = (body['today_rides'] ?? 0) as int;
      todayEarning  = (body['today_earning'] ?? 0).toDouble();
      weekEarning   = (body['week_earning'] ?? 0).toDouble();
      monthEarning  = (body['month_earning'] ?? 0).toDouble();
      final wallet  = body['wallet'];
      if (wallet != null) {
        walletBalance = (wallet['balance'] ?? 0).toDouble();
      }
      summaryLoaded = true;
      _buildEarningChart(body);
    }
    update();
  }

  void _buildEarningChart(Map<String, dynamic> body) {
    // Build a simple 7-day chart from today/week data
    earningChartList = [];
    maxValue = weekEarning > 0 ? weekEarning : 1;
    // Placeholder — real chart data would come from a daily breakdown endpoint
    for (int i = 0; i < 7; i++) {
      earningChartList.add(FlSpot(i.toDouble(), 0));
    }
    // Put today's earning on the last bar
    if (earningChartList.isNotEmpty) {
      earningChartList[6] = FlSpot(6, todayEarning);
      if (todayEarning > maxValue) maxValue = todayEarning;
    }
  }

  void setOverviewType(String name) {
    _selectedOverview = name;
    update();
  }

  void rideCancellationReasonList() async {}

  Future<void> getDailyLog() async {
    await loadEarningSummary();
  }
}
