import 'package:get/get_connect/http/src/response/response.dart';

abstract class RideOrderServiceInterface {
  Future<Response> login(String phone, String password);
  Future<Response> logout();
  Future<Response> updateFcmToken(String token);
  Future<Response> getProfile();
  Future<Response> toggleOnlineStatus(bool online);
  Future<Response> sendHeartbeat();
  Future<Response> updateLocation({
    required double latitude,
    required double longitude,
    double? heading,
    double? speedKmph,
  });
  Future<Response> getRideOffers();
  Future<Response> acceptRide(int rideId);
  Future<Response> rejectRide(int rideId);
  Future<Response> updateRideStatus(int rideId, String newStatus);
  Future<Response> startRide(int rideId, String otp);
  Future<Response> completeRide({
    required int rideId,
    required double actualDistanceKm,
    required double actualDurationMin,
    double waitingMinutes = 0,
    double tollAmount = 0,
  });
  Future<Response> getRideList(String type, {int limit = 20, int offset = 1});
  Future<Response> getEarningSummary();
  Future<Response> getEarningTransactions({int limit = 25, int offset = 1});
  Future<Response> getDocuments();
  String? getDriverToken();
  Future<void> saveDriverToken(String token);
  Future<void> clearDriverToken();
  bool isDriverLoggedIn();
}
