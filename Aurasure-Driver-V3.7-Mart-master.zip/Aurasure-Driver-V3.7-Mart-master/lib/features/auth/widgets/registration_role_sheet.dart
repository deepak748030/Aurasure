import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sixam_mart_delivery/features/auth/screens/rider_registration_screen.dart';
import 'package:sixam_mart_delivery/helper/route_helper.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Shown at sign-up when both delivery-man and rider registration are enabled.
/// Lets the applicant choose which kind of account to create.
class RegistrationRoleSheet extends StatelessWidget {
  const RegistrationRoleSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(Dimensions.radiusLarge)),
      ),
      padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 40, height: 4,
          decoration: BoxDecoration(
            color: Theme.of(context).disabledColor.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(height: Dimensions.paddingSizeLarge),

        Text('register_as'.tr, style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
        const SizedBox(height: Dimensions.paddingSizeSmall),
        Text('choose_the_type_of_account_you_want_to_create'.tr,
            textAlign: TextAlign.center,
            style: robotoRegular.copyWith(
              fontSize: Dimensions.fontSizeSmall,
              color: Theme.of(context).disabledColor,
            )),
        const SizedBox(height: Dimensions.paddingSizeLarge),

        _RoleTile(
          icon: Icons.delivery_dining_rounded,
          title: 'delivery_man'.tr,
          subtitle: 'deliver_orders_to_customers'.tr,
          onTap: () {
            Get.back();
            Get.toNamed(RouteHelper.getDeliverymanRegistrationRoute());
          },
        ),
        const SizedBox(height: Dimensions.paddingSizeDefault),
        _RoleTile(
          icon: Icons.local_taxi_rounded,
          title: 'rider'.tr,
          subtitle: 'drive_passengers_and_earn'.tr,
          onTap: () {
            Get.back();
            Get.to(() => const RiderRegistrationScreen());
          },
        ),
        const SizedBox(height: Dimensions.paddingSizeSmall),
      ]),
    );
  }
}

class _RoleTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _RoleTile({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
      child: Container(
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          border: Border.all(color: Theme.of(context).disabledColor.withValues(alpha: 0.3)),
        ),
        child: Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: Theme.of(context).primaryColor),
          ),
          const SizedBox(width: Dimensions.paddingSizeDefault),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault)),
            const SizedBox(height: 2),
            Text(subtitle, style: robotoRegular.copyWith(
              fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).disabledColor,
            )),
          ])),
          Icon(Icons.arrow_forward_ios_rounded, size: 16, color: Theme.of(context).disabledColor),
        ]),
      ),
    );
  }
}
