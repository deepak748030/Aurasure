import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sixam_mart_delivery/api/api_client.dart';
import 'package:sixam_mart_delivery/features/profile/controllers/profile_controller.dart';
import 'package:sixam_mart_delivery/features/profile/domain/models/profile_model.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_constants.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Add / edit vehicle screen for ride drivers.
/// Submits to /api/v1/ride-share/driver/documents (vehicle registration).
class AddVehicleScreen extends StatefulWidget {
  final Vehicle? vehicleInfo;
  const AddVehicleScreen({super.key, this.vehicleInfo});

  @override
  State<AddVehicleScreen> createState() => _AddVehicleScreenState();
}

class _AddVehicleScreenState extends State<AddVehicleScreen> {
  final _formKey = GlobalKey<FormState>();
  final _plateCtrl    = TextEditingController();
  final _vinCtrl      = TextEditingController();
  final _nameCtrl     = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    final v = widget.vehicleInfo;
    if (v != null) {
      _plateCtrl.text = v.licencePlateNumber ?? '';
      _vinCtrl.text   = v.vinNumber ?? '';
      _nameCtrl.text  = v.name ?? '';
    }
  }

  @override
  void dispose() {
    _plateCtrl.dispose();
    _vinCtrl.dispose();
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString(RideConstants.tokenKey) ?? '';
      final apiClient = Get.find<ApiClient>();

      final response = await apiClient.postData(
        RideConstants.vehicleUri,
        {
          'license_plate': _plateCtrl.text.trim(),
          'name': _nameCtrl.text.trim(),
          'vin_number': _vinCtrl.text.trim(),
        },
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization': 'Bearer $token',
        },
        handleError: false,
      );

      if (response.statusCode == 200) {
        // Refresh profile so home screen reflects pending vehicle status
        await Get.find<ProfileController>().getProfile();
        Get.back();
        Get.snackbar(
          'success'.tr,
          'vehicle_request_submitted'.tr,
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );
      } else {
        final msg = response.body?['errors']?[0]?['message'] ?? response.statusText ?? 'something_went_wrong'.tr;
        Get.snackbar('error'.tr, msg,
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.red,
            colorText: Colors.white);
      }
    } catch (e) {
      Get.snackbar('error'.tr, 'something_went_wrong'.tr,
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white);
    }

    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        elevation: 0,
        title: Text(
          widget.vehicleInfo == null ? 'add_vehicle_info'.tr : 'vehicle_details'.tr,
          style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        child: Form(
          key: _formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

            const SizedBox(height: Dimensions.paddingSizeSmall),
            _SectionHeader('vehicle_information'.tr),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            _Field(
              controller: _nameCtrl,
              label: 'vehicle_name'.tr,
              hint: 'e.g. Toyota Camry',
              icon: Icons.directions_car_outlined,
            ),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            _Field(
              controller: _plateCtrl,
              label: 'licence_plate_number'.tr,
              hint: 'e.g. MH01AB1234',
              icon: Icons.credit_card_outlined,
            ),
            const SizedBox(height: Dimensions.paddingSizeDefault),

            _Field(
              controller: _vinCtrl,
              label: 'vin_number'.tr,
              hint: 'Vehicle Identification Number',
              icon: Icons.numbers_outlined,
              required: false,
            ),
            const SizedBox(height: Dimensions.paddingSizeLarge * 2),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).primaryColor,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                  ),
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 22, height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : Text(
                        'submit'.tr,
                        style: robotoBold.copyWith(fontSize: Dimensions.fontSizeDefault),
                      ),
              ),
            ),

          ]),
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);
  @override
  Widget build(BuildContext context) {
    return Text(title,
        style: robotoBold.copyWith(
          fontSize: Dimensions.fontSizeDefault,
          color: Theme.of(context).textTheme.bodyLarge?.color,
        ));
  }
}

class _Field extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool required;
  const _Field({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.required = true,
  });

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label,
          style: robotoMedium.copyWith(
            fontSize: Dimensions.fontSizeSmall,
            color: Theme.of(context).textTheme.bodyLarge?.color,
          )),
      const SizedBox(height: 6),
      TextFormField(
        controller: controller,
        validator: required
            ? (v) => (v == null || v.trim().isEmpty) ? '$label ${'is_required'.tr}' : null
            : null,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: robotoRegular.copyWith(
            color: Theme.of(context).disabledColor,
            fontSize: Dimensions.fontSizeSmall,
          ),
          prefixIcon: Icon(icon, size: 20, color: Theme.of(context).disabledColor),
          filled: true,
          fillColor: Theme.of(context).cardColor,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: Dimensions.paddingSizeDefault,
            vertical: Dimensions.paddingSizeDefault,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
            borderSide: BorderSide(color: Theme.of(context).disabledColor.withValues(alpha: 0.3)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
            borderSide: BorderSide(color: Theme.of(context).disabledColor.withValues(alpha: 0.3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
            borderSide: BorderSide(color: Theme.of(context).primaryColor),
          ),
        ),
      ),
    ]);
  }
}
