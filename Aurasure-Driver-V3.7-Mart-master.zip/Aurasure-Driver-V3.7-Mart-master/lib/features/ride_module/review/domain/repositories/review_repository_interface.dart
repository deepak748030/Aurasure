import 'package:get/get_connect/http/src/response/response.dart';

abstract class ReviewRepositoryInterface {
  /// GET driver profile — avg_rating and rating_count come from here.
  Future<Response> getDriverProfile();
}
