import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sixam_mart_delivery/features/auth/controllers/auth_controller.dart';
import 'package:sixam_mart_delivery/features/notification/controllers/notification_controller.dart';
import 'package:sixam_mart_delivery/features/profile/controllers/profile_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/ride_order/controllers/ride_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/controllers/trip_controller.dart';
import 'package:sixam_mart_delivery/features/ride_module/home/widgets/rider_active_ride_card.dart';
import 'package:sixam_mart_delivery/features/ride_module/home/widgets/rider_activity_grid.dart';
import 'package:sixam_mart_delivery/features/ride_module/home/widgets/rider_earning_card.dart';
import 'package:sixam_mart_delivery/features/ride_module/home/widgets/rider_online_toggle.dart';
import 'package:sixam_mart_delivery/features/ride_module/home/widgets/rider_stats_row.dart';
import 'package:sixam_mart_delivery/features/ride_module/home/widgets/rider_vehicle_status_card.dart';
import 'package:sixam_mart_delivery/helper/route_helper.dart';
import 'package:sixam_mart_delivery/util/app_constants.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/images.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Full rider home screen — completely self-contained inside ride_module.
class RiderHomeScreen extends StatefulWidget {
  const RiderHomeScreen({super.key});

  @override
  State<RiderHomeScreen> createState() => _RiderHomeScreenState();
}

class _RiderHomeScreenState extends State<RiderHomeScreen> {
  late final AppLifecycleListener _lifecycleListener;
  bool _isNotificationPermissionGranted = true;
  bool _isBatteryOptimizationGranted = true;

  @override
  void initState() {
    super.initState();

    _lifecycleListener = AppLifecycleListener(
      onStateChange: _onLifecycleChanged,
    );

    _loadData();

    Future.delayed(const Duration(milliseconds: 200), () {
      _checkPermissions();
    });
  }

  @override
  void dispose() {
    _lifecycleListener.dispose();
    super.dispose();
  }

  void _onLifecycleChanged(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkPermissions();
    }
  }

  Future<void> _loadData() async {
    // Load profile first — this syncs the online state and confirms the token is ready
    final profile = await Get.find<ProfileController>().getProfile();
    if (profile != null) {
      final isOnline = (profile.active ?? 0) == 1;
      Get.find<RideController>().setOnlineFromProfile(isOnline);
      // If online, send real GPS location immediately
      if (isOnline) {
        _sendGpsLocation();
      }
    }

    // Now load ride data (token is confirmed present)
    Get.find<TripController>().getDailyLog();
    Get.find<RideController>().getLastRideDetail();
    Get.find<RideController>().ongoingTripList();
    Get.find<ProfileController>().getProfileLevelInfo();
  }

  Future<void> _sendGpsLocation() async {
    try {
      final permission = await Permission.location.status;
      if (!permission.isGranted) return;
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
      );
      await Get.find<RideController>().updateLocation(
        pos.latitude, pos.longitude,
        heading: pos.heading,
      );
    } catch (_) {
      // GPS unavailable — heartbeat was already sent by toggleOnline/setOnlineFromProfile
    }
  }

  Future<void> _checkPermissions() async {
    final notifStatus = await Permission.notification.status;
    final batteryStatus = await Permission.ignoreBatteryOptimizations.status;

    if (notifStatus.isDenied || notifStatus.isPermanentlyDenied) {
      if (mounted) setState(() { _isNotificationPermissionGranted = false; });
      await Get.find<AuthController>().setNotificationActive(false);
    } else if (batteryStatus.isDenied) {
      if (mounted) setState(() { _isBatteryOptimizationGranted = false; });
    } else {
      if (mounted) setState(() {
        _isNotificationPermissionGranted = true;
        _isBatteryOptimizationGranted = true;
      });
      Get.find<ProfileController>().setBackgroundNotificationActive(true);
    }

    if (batteryStatus.isDenied) {
      Get.find<ProfileController>().setBackgroundNotificationActive(false);
    }
  }

  Future<void> _requestNotificationPermission() async {
    if (await Permission.notification.request().isGranted) {
      _checkPermissions();
    } else {
      await openAppSettings();
      _checkPermissions();
    }
  }

  Future<void> _requestBatteryOptimization() async {
    final status = await Permission.ignoreBatteryOptimizations.status;
    if (status.isGranted) return;
    if (status.isDenied) {
      await Permission.ignoreBatteryOptimizations.request();
    } else {
      openAppSettings();
    }
    _checkPermissions();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        surfaceTintColor: Theme.of(context).cardColor,
        shadowColor: Theme.of(context).disabledColor.withValues(alpha: 0.5),
        elevation: 2,
        leading: Padding(
          padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
          child: Image.asset(Images.logo, height: 30, width: 30),
        ),
        titleSpacing: 0,
        title: Text(
          AppConstants.appName,
          style: robotoMedium.copyWith(
            color: Theme.of(context).textTheme.bodyLarge!.color,
            fontSize: Dimensions.fontSizeDefault,
          ),
        ),
        actions: [
          GetBuilder<NotificationController>(builder: (notifCtrl) {
            return IconButton(
              icon: Stack(children: [
                Icon(Icons.notifications_outlined, size: 25,
                    color: Theme.of(context).textTheme.bodyLarge!.color),
                if (notifCtrl.hasNotification)
                  Positioned(
                    top: 0, right: 0,
                    child: Container(
                      height: 10, width: 10,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.error,
                        shape: BoxShape.circle,
                        border: Border.all(width: 1, color: Theme.of(context).cardColor),
                      ),
                    ),
                  ),
              ]),
              onPressed: () => Get.toNamed(RouteHelper.getNotificationRoute()),
            );
          }),
          const SizedBox(width: Dimensions.paddingSizeSmall),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: Column(children: [

          // ── Notification permission warning ─────────────────────
          if (!_isNotificationPermissionGranted)
            _PermissionBanner(
              isBattery: false,
              onTap: _requestNotificationPermission,
              onClose: () => setState(() => _isNotificationPermissionGranted = true),
            ),

          // ── Battery optimization warning ────────────────────────
          if (_isBatteryOptimizationGranted == false)
            _PermissionBanner(
              isBattery: true,
              onTap: _requestBatteryOptimization,
              onClose: () => setState(() => _isBatteryOptimizationGranted = true),
            ),

          Expanded(
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeDefault),
              child: Column(children: [

                // ── Online / offline toggle ───────────────────────
                const RiderOnlineToggle(),
                const SizedBox(height: Dimensions.paddingSizeDefault),

                // ── Vehicle status / active ride ──────────────────
                GetBuilder<ProfileController>(builder: (profileCtrl) {
                  final vehicle = profileCtrl.profileModel?.vehicle;
                  final needsVehicle = vehicle == null ||
                      vehicle.vehicleRequestStatus == 'pending';
                  if (needsVehicle) {
                    return RiderVehicleStatusCard(vehicle: vehicle);
                  }
                  return const RiderActiveRideCard();
                }),

                // ── Earnings card ─────────────────────────────────
                const RiderEarningCard(),

                // ── Stats row ─────────────────────────────────────
                const RiderStatsRow(),

                // ── Activity grid ─────────────────────────────────
                const RiderActivityGrid(),

                const SizedBox(height: Dimensions.paddingSizeLarge),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

// ── Permission warning banner ──────────────────────────────────────────────

class _PermissionBanner extends StatelessWidget {
  final bool isBattery;
  final VoidCallback onTap;
  final VoidCallback onClose;
  const _PermissionBanner({
    required this.isBattery,
    required this.onTap,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    if (!GetPlatform.isAndroid) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      color: Theme.of(context).textTheme.bodyLarge!.color?.withValues(alpha: 0.7),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
          child: Row(children: [
            if (isBattery)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Image.asset(Images.allertIcon, height: 20, width: 20),
              ),
            Expanded(child: Row(children: [
              Flexible(
                child: Text(
                  isBattery
                      ? 'for_better_performance_allow_notification_to_run_in_background'.tr
                      : 'notification_is_disabled_please_allow_notification'.tr,
                  maxLines: 2,
                  style: robotoRegular.copyWith(
                    fontSize: Dimensions.fontSizeSmall,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),
              const Icon(Icons.arrow_circle_right_rounded, color: Colors.white, size: 24),
            ])),
          ]),
        ),
      ),
    );
  }
}
