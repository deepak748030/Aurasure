import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shimmer_animation/shimmer_animation.dart';
import 'package:sixam_mart_delivery/common/widgets/title_widget.dart';
import 'package:sixam_mart_delivery/features/ride_module/trip/controllers/trip_controller.dart';
import 'package:sixam_mart_delivery/helper/price_converter_helper.dart';
import 'package:sixam_mart_delivery/util/dimensions.dart';
import 'package:sixam_mart_delivery/util/images.dart';
import 'package:sixam_mart_delivery/util/styles.dart';

/// Rider earnings card — data from TripController (earning/summary endpoint).
class RiderEarningCard extends StatelessWidget {
  const RiderEarningCard({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TripController>(builder: (ctrl) {
      // summaryLoaded is set to true once earning/summary API responds.
      // All-zero is valid for a new driver — don't treat it as "loading".
      final bool loaded = ctrl.summaryLoaded;

      return Padding(
        padding: const EdgeInsets.fromLTRB(
          Dimensions.paddingSizeDefault, 0,
          Dimensions.paddingSizeDefault, Dimensions.paddingSizeDefault,
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          TitleWidget(title: 'earnings'.tr),
          const SizedBox(height: Dimensions.paddingSizeSmall),

          Container(
            padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
              color: Theme.of(context).primaryColor,
            ),
            child: Column(children: [

              // Wallet balance
              Row(children: [
                const SizedBox(width: Dimensions.paddingSizeSmall),
                Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(50),
                  ),
                  padding: const EdgeInsets.only(
                    bottom: Dimensions.paddingSizeDefault,
                    left: Dimensions.paddingSizeDefault,
                    top: Dimensions.paddingSizeSmall,
                    right: Dimensions.paddingSizeSmall,
                  ),
                  child: Image.asset(Images.wallet, width: 40, height: 40),
                ),
                const SizedBox(width: Dimensions.paddingSizeLarge),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('balance'.tr,
                      style: robotoMedium.copyWith(
                        fontSize: Dimensions.fontSizeSmall,
                        color: Theme.of(context).cardColor.withValues(alpha: 0.9),
                      )),
                  const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                  loaded
                      ? Text(
                          PriceConverterHelper.convertPrice(ctrl.walletBalance),
                          style: robotoBold.copyWith(fontSize: 24, color: Theme.of(context).cardColor),
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                        )
                      : Container(height: 30, width: 60, color: Colors.white),
                ]),
              ]),
              const SizedBox(height: Dimensions.paddingSizeLarge),

              // Today / Week / Month
              Row(children: [
                _Cell(title: 'today'.tr, amount: loaded ? ctrl.todayEarning : null),
                Container(height: 30, width: 1,
                    color: Theme.of(context).cardColor.withValues(alpha: 0.8)),
                _Cell(title: 'this_week'.tr, amount: loaded ? ctrl.weekEarning : null),
                Container(height: 30, width: 1,
                    color: Theme.of(context).cardColor.withValues(alpha: 0.8)),
                _Cell(title: 'this_month'.tr, amount: loaded ? ctrl.monthEarning : null),
              ]),

            ]),
          ),

        ]),
      );
    });
  }
}

class _Cell extends StatelessWidget {
  final String title;
  final double? amount;
  const _Cell({required this.title, required this.amount});

  @override
  Widget build(BuildContext context) {
    return Expanded(child: Column(children: [
      Text(title,
          style: robotoMedium.copyWith(
            fontSize: Dimensions.fontSizeSmall,
            color: Theme.of(context).cardColor.withValues(alpha: 0.8),
          )),
      const SizedBox(height: Dimensions.paddingSizeSmall),
      amount != null
          ? Text(
              PriceConverterHelper.convertPrice(amount),
              style: robotoMedium.copyWith(
                fontSize: Dimensions.fontSizeLarge,
                color: Theme.of(context).cardColor,
              ),
              maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
            )
          : Shimmer(
              duration: const Duration(seconds: 2),
              enabled: true,
              color: Colors.grey[500]!,
              child: Container(height: 20, width: 40, color: Colors.white),
            ),
    ]));
  }
}
